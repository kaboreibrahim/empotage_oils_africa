default_app_config = 'stock_backend.apps.StockBackendConfig'
