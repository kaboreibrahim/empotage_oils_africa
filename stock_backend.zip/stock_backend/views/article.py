from django.http import HttpRequest, HttpResponseRedirect
from django.urls import reverse, reverse_lazy
from stock_backend.forms import ArticleForm, ArticleVariantForm
from stock_backend.models import Article, AttributeValue, ArticleVariant
from django.views.generic.edit import CreateView, DeleteView, UpdateView
from django.views.generic import ListView, DetailView
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.forms import modelformset_factory
from braces.views import FormMessagesMixin
from loguru import logger
from django.contrib import messages
import sys

logger.add(sys.stdout, colorize=True,
           format="<green>{time}</green> <level>{message}</level>")


@method_decorator(login_required, name='dispatch')
class ArticleListView(ListView):
    """
        vue d'affichage de la liste des articles
    """
    model = Article
    context_object_name = 'article_list'
    template_name = "pages/articles/list.html"

    def get_queryset(self):
        queryset = Article.objects.all()
        return queryset


@method_decorator(login_required, name='dispatch')
class ArticleCreateView(FormMessagesMixin, CreateView):
    """
      Vue de création d'un article
    """
    model = Article
    form_class = ArticleForm
    template_name = "pages/articles/create.html"
    success_url = reverse_lazy('article_list')
    form_invalid_message = "Oups, quelque chose s'est mal passé!"

    def get_form_valid_message(self):
        return u"{0} crée avec succès!".format(self.object.label)

    def post(self, request: HttpRequest, *args, **kwargs):
        # Look up the author we're interested in.
        logger.debug(f"Article Post : {request.POST}")
        # Actually record interest somehow here!
        form = ArticleForm(request.POST)
        if form.is_valid():
            form.save()
            messages.add_message(request,messages.SUCCESS,"Enregistrement effectuer avec succés  de l'article " )
            return HttpResponseRedirect(reverse('article_list'))
        else:
            logger.debug(f"Article form errors : {form.errors}")
            messages.add_message(request,messages.ERROR,"  l'article  est deja enregistre " )

            return HttpResponseRedirect(reverse('article-new'), {"form": form})

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        variants_formset = modelformset_factory(
            ArticleVariant, ArticleVariantForm, fields=('article', 'attributes', 'price'), extra=1)
        queryset = AttributeValue.objects.none().all()
        formset = variants_formset(
            queryset=queryset,
        )
        logger.debug(f"Form type: {type(formset)}")
        # Add in the publisher
        context['form'] = ArticleForm
        context['formset'] = formset
        context['method'] = "post"
        return context


@method_decorator(login_required, name='dispatch')
class ArticleUpdateView(FormMessagesMixin, UpdateView):
    """
      vue de mise à jour d'un article
    """
    model = Article
    form_class = ArticleForm
    template_name = "pages/articles/create.html"
    success_url = reverse_lazy('article_list')
    form_invalid_message = "Oups, quelque chose s'est mal passé!"

    def get_form_valid_message(self):
        return u"{0} modifié avec succès!".format(self.object.label)

    # Recupère l'identifiant de l'objet caché dans le formulaire pour modifier le bon objet
    def get_object(self, **kwargs):
        logger.debug("Project Update data : {}".format(self.request.body))
        return Article.objects.get(pk=self.request.POST.get('pk'))

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        context['method'] = "put"
        return context


@method_decorator(login_required, name='dispatch')
class ArticleDeleteView(DeleteView):
    model = Article
    success_url = reverse_lazy('article_list')


@method_decorator(login_required, name='dispatch')
class ArticleDetailView(DetailView):
    """
        Vue d'affichage d'un article
    """
    model = Article
    template_name = "pages/articles/create.html"

    @logger.catch
    def get_context_data(self, **kwargs):
        """
            Surchage l'objet context
        """
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        obj = self.get_object()
        logger.debug(f"Detail request : {obj.pk}")
        variants_formset = modelformset_factory(
            ArticleVariant, ArticleVariantForm, fields=('article', 'attributes', 'price'), extra=1)
        # AttributeValueFormSet = inlineformset_factory(parent_model=Article,
        #                                               model=AttributeValue, form=AttributeValueForm, fields=('attribute', 'value'), extra=1)
        # On récupère les variantes de cet article
        queryset = ArticleVariant.objects.filter(article=obj).all()

        formset = variants_formset(
            queryset=queryset,
        )
        logger.debug(f"Form type: {type(formset)}")
        context['form'] = ArticleForm(instance=obj)
        context['formset'] = formset
        context['object'] = obj
        context['method'] = "put"
        return context
