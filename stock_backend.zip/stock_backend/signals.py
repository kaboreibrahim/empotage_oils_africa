"""# signals.py

from django.db.models.signals import m2m_changed,pre_save
from django.dispatch import receiver
from .models import Rapport,firstprojet
from django.utils import timezone

@receiver(m2m_changed, sender=Rapport.flexitanks.through)
def update_flexitanks_status(sender, instance, action, **kwargs):
    if action == 'post_add':
        for flexitank in instance.flexitanks.all():
            flexitank.etat = 'SORTIE'
            flexitank.date_sortie = timezone.now()
            flexitank.save()
            instance.Project.terminer_projet()

@receiver(m2m_changed, sender=Rapport.heating_pads.through)
def update_heatingpads_status(sender, instance, action, **kwargs):
    if action == 'post_add':
        for heatingpad in instance.heating_pads.all():
            heatingpad.Etat = 'SORTIE'
            heatingpad.date_sortie = timezone.now()
            heatingpad.save()
 """