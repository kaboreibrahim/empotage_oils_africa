from django.http import HttpRequest, HttpResponseRedirect
from django.urls import reverse, reverse_lazy
from stock_backend.forms import ArticleVariantForm
from stock_backend.models import ArticleVariant
from django.views.generic.edit import CreateView, DeleteView, UpdateView
from django.views.generic import ListView, DetailView
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from braces.views import FormMessagesMixin
from django.shortcuts import render
from django.contrib import messages


    
@method_decorator(login_required, name='dispatch')
class ArticleVariantListView(ListView):
    """
        vue d'affichage de la liste des variantes des articles
    """
    model =ArticleVariant
    context_object_name = 'ArticleVariant_list'
    template_name = "pages/ArticleVariant/list.html"


    def get_queryset(self):
        queryset = ArticleVariant.objects.all()
        return queryset
    
@method_decorator(login_required, name='dispatch')
class  ArticleVariantCreateView(FormMessagesMixin, CreateView):
    """
      Vue de création d'un transfer
    """
    model = ArticleVariant
    form_class = ArticleVariantForm
    template_name="pages/ArticleVariant/create.html"
    success_url=reverse_lazy('ArticleVariant_list')
    form_invalid_message="Oups,quelque chose s'est ma passé!"
    print(form_invalid_message)
    
    
    def get_form_valid_message(self):
        return u" Ajouter avec succés!"
    
    def post(self, request: HttpRequest, *args, **kwargs):
        # Look up the author we're interested in.
        print(f"ArticleVariant Post : {request.POST}")
        # Actually record interest somehow here!
        form = ArticleVariantForm(request.POST)
        if form.is_valid():
            form.save()
            messages.add_message(request,messages.SUCCESS,"Enregistrement effectuer avec succés  de la variante de l'article " )
            return HttpResponseRedirect(reverse('ArticleVariant_list'), {"form": form})

        
        else:
            print(f"Transfer form errors : {form.errors}")
            return HttpResponseRedirect(reverse('ArticleVariant_new'), {"form": form})
            
    
    
    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        context['form'] =ArticleVariantForm
        context['method'] = "post"
        return context
    
    

@method_decorator(login_required, name='dispatch')
class ArticleVariantUpdateView(FormMessagesMixin, UpdateView):
    """
      vue de mise à jour d'un transfer
    """
    model = ArticleVariant
    form_class = ArticleVariantForm
    template_name = "pages/ArticleVariant/update.html"
    success_url = reverse_lazy('ArticleVariant_list')
    form_invalid_message = "Oups, quelque chose s'est mal passé!"
    
    def get_form_valid_message(self):
        return u" Modification effectueé avec succès!"

    # Recupère l'identifiant de l'objet caché dans le formulaire pour modifier le bon objet
    def get_object(self, **kwargs):
        print("ArticleVariant Update data : {}".format(self.request.body))
        return ArticleVariant.objects.get(pk=self.request.POST.get('pk'))

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        context['method'] = "put"
        return context

@method_decorator(login_required, name='dispatch')
class ArticleVariantDeleteView(DeleteView):
    model = ArticleVariant
    success_url = reverse_lazy('ArticleVariant_list')


@method_decorator(login_required, name='dispatch')
class ArticleVariantDetailView(DetailView):
    """
        Vue d'affichage d'un category
    """
    model = ArticleVariant
    template_name = "pages/ArticleVariant/create.html"

    def get_context_data(self, **kwargs):
        """
            Surchage l'objet context
        """
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        obj = self.get_object()
        print(f"Detail request : {obj.pk}")
        context['form'] = ArticleVariantForm(instance=obj)
        context['object'] = obj
        context['method'] = "put"
        return context

    
    
    