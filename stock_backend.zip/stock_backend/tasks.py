# votre_app/tasks.py
from celery import shared_task
from django.core.mail import send_mail
from django.utils import timezone
from datetime import datetime
from stock_backend.models import ArticleSerialLot
from django.contrib import messages

from django.core.mail import send_mail


@shared_task
def send_stock_alert_email_task(transfer_groups, request):
    message_global = "Alerte de stock :\n"
    for transfer_destination, transfer_entries in transfer_groups.items():
        for transfer_entry in transfer_entries:
            if transfer_entry['total_quantity_rest'] == 0:
                message_global += f"\n le Projet {transfer_destination} le stock du produit  {transfer_entry['serial_lot_of_item']} est épuisé, Veuillez envisager de procéder à un réapprovisionnement."

    if len(message_global) > len("Alerte de stock :\n"):  # Vérifie s'il y a des alertes à envoyer
        sujet = "Alerte de stock épuisé"
        send_mail(
            sujet,
            message_global,
            'ibrahimkabore025@gmail.com',  # Remplacez par votre adresse Gmail ou l'adresse email de l'expéditeur
            ['ibrahimkabore025@gmail.com'],  # Remplacez par l'adresse email du destinataire
            fail_silently=False,
        )
        messages.add_message(request, messages.INFO, 'Vous avez reçu le rapport des stocks à réapprovisionner par email.')
    else:
        messages.add_message(request, messages.INFO, 'Aucune alerte de stock à signaler.')
        
   
                      
@shared_task
def send_expired_articles_email_task(request, lots_serial_expires):
    current_datetime = datetime.now().replace(tzinfo=timezone.utc)
    lots_serial_expires = ArticleSerialLot.objects.filter(expiry_date__lte=current_datetime)
   
    if lots_serial_expires.exists():
        sujet = "Articles expirés"
        message = "Liste des articles expirés :\n"

        for lot_serial in lots_serial_expires:
            message += f" -\nArticle : {lot_serial.article_variant}, a expiré à la date du : {lot_serial.expiry_date}"

        send_mail(
            sujet,
            message,
            'ibrahimkabore025@gmail.com',  # Remplacez par votre adresse Gmail ou l'adresse email de l'expéditeur
            ['ibrahimkabore025@gmail.com'],  # Remplacez par l'adresse email du destinataire
            fail_silently=False,
        )

        messages.add_message(request, messages.INFO, 'Vous avez reçu le rapport des produits expirés par email.')
    else:
        messages.add_message(request, messages.INFO, 'Aucun produit expiré à signaler.')
