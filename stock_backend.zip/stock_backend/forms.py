from typing import Any
from django import forms
from django.forms import  ModelForm,DateTimeInput

from crispy_forms.layout import Layout, Column
from crispy_forms.helper import FormHelper

from .models import *

class listForm(ModelForm):
    class Meta:
        model = Transfer
        fields = ['origin_of_transfer','destination_of_transfer','serial_lot_of_item']
        required_fields = ['origin_of_transfer', 'serial_lot_of_item', 'destination_of_transfer']
        widgets = {
            'origin_of_transfer': forms.HiddenInput(),
            'date_debut': DateTimeInput(attrs={"type": "date", 'class': 'form-control date-field'}),
            'date_fin': DateTimeInput(attrs={"type": "date", 'class': 'form-control date-field'})
        }
        labels = {
            'origin_of_transfer': 'origine du transfert',
            'destination_of_transfer': ' le mon du projet ',
            'serial_lot_of_item':  "choisir l'aricle ",
            'date_debut': 'Date de début',
            'date_fin': 'Date de fin'
        }
    def __init__(self, *args, **kwargs):
        super(listForm, self).__init__(*args, **kwargs)
        
        # Définir la valeur de origin_of_transfer
        self.initial['origin_of_transfer'] = Stock.objects.get(label='FOURNISSEURS')
        
        # Filtrer destination_of_transfer pour afficher seulement les stocks qui ont le même nom que les projets
        user = kwargs.get('initial').get('user')
        if user and not user.is_superuser:
            user_profile = UserProfile.objects.get(user=user)
            project = user_profile.project
            project_choices = [("", "------------")] + [(stock.pk, str(stock.label)) for stock in project.project_stocks.filter(label=project.title).exclude(label='FOURNISSEURS')]
            self.fields['destination_of_transfer'].choices = project_choices
            
            
        else:
            
            # Récupérer les noms de projets
            project_names = Project.objects.values_list('title', flat=True)

            # Filtrer destination_of_transfer pour afficher seulement les stocks qui ont le même nom que les projets
            self.fields['destination_of_transfer'].queryset = Stock.objects.filter(label__in=project_names).exclude(label='FOURNISSEURS')
                

        # Champ pour afficher les ID de serial_lot_of_item dans une liste déroulante
        self.fields['serial_lot_of_item'].queryset = ArticleSerialLot.objects.all()

         # Champ pour saisir la date de début
        self.fields['date_debut'] = forms.DateField(widget=forms.DateInput(attrs={'type': 'date', 'class': 'date-field'}),required=False)

        # Champ pour saisir la date de fin
        self.fields['date_fin'] = forms.DateField(widget=forms.DateInput(attrs={'type': 'date', 'class': 'date-field'}),required=False)
        
        
class ArticleSerialLotForm(ModelForm):
    def __init__(self, *args, **kwargs):
        super(ArticleSerialLotForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper(self)
        self.helper.layout = Layout(
            Column('code',
                   'expiry_date',
                   'article_variant',
                   'date_created_at',
                   
            ),
        )

  
    class Meta:
        model = ArticleSerialLot
        fields = ['code','expiry_date','article_variant','date_created_at']
        widgets={
            'expiry_date':DateTimeInput(attrs={"type": "date"})
        }
        labels = {
            'code': 'Numero de serie',
            'expiry_date': "Date d' expiration ",
            'article_variant':  "l'article variant ",
            'date_created_at': ' Date de Creation ',
        }



class TransferForm(forms.ModelForm):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
         # Définir la valeur de origin_of_transfer
        self.initial['origin_of_transfer'] = Stock.objects.get(label='FOURNISSEURS')


       

        # Récupérer les noms de projets
        project_names = Project.objects.values_list('title', flat=True)

        # Filtrer destination_of_transfer pour afficher seulement les stocks qui ont le même nom que les projets
        self.fields['destination_of_transfer'].queryset = Stock.objects.filter(label__in=project_names).exclude(label='FOURNISSEURS')
        

    class Meta:
        model = Transfer
        fields = ['origin_of_transfer','nom_fournissuer', 'destination_of_transfer', 'quantity', 'serial_lot_of_item']
        labels = {
            'nom_fournissuer':'Nom du fournisseur',
            'origin_of_transfer': ' fournisseur',
            'destination_of_transfer': 'Nom du Site  ',
            'quantity': 'Quantité',
            'serial_lot_of_item': 'Article',
        }
        widgets={
            'origin_of_transfer': forms.HiddenInput(),
            }
 
class TransferFormout(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        project_names = Project.objects.values_list('title', flat=True)
       
        self.fields['origin_of_transfer'].queryset = Stock.objects.filter(label__in=project_names).exclude(label='FOURNISSEURS')
            
                # Récupérer les projets qui ne sont pas rattachés aux fournisseurs
        projects = Project.objects.exclude(title='FOURNISSEURS')

        # Récupérer les stocks dont le nom est différent de leur projet et qui ne sont pas rattachés aux fournisseurs
        stocks = Stock.objects.filter(project__in=projects).exclude(label__in=[p.title for p in projects])

        # Filtrer destination_of_transfer pour afficher seulement les stocks correspondants
        self.fields['destination_of_transfer'].queryset = stocks
        
         # Filtrer les Flexitanks avec le statut "EN_STOCK"
        # self.fields['flexitank'].queryset = Flexitanks.objects.filter(etat='EN_STOCK')
        
        # # Filtrer les Heating Pads avec le statut "EN_STOCK" 
        # self.fields['heating_pad'].queryset = HeatingPad.objects.filter(Etat='EN_STOCK')
        
        self.initial['origin_of_transfer'] = Stock.objects.get(label='FOURNISSEURS')
        self.fields['projet'].queryset = firstprojet.objects.filter(statut='attente')

        

    class Meta:
        model = Transfer
        fields = ['origin_of_transfer', 'destination_of_transfer','projet', 'quantity', 'serial_lot_of_item']
        labels = {
            'origin_of_transfer': 'Nom du Site ',
            'destination_of_transfer': ' le client',
            'projet': ' le nom du projet',
            'quantity': 'Quantité',
            'serial_lot_of_item': 'Article',
        }

class RapportForm(ModelForm):
    def __init__(self, *args, **kwargs):
        super(RapportForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper(self)

        # Filtrer les flexitanks avec le statut "EN_STOCK"
        self.fields['flexitanks'].queryset = Flexitanks.objects.filter(etat='EN_STOCK')

        # Filtrer les Heating Pads avec le statut "EN_STOCK"
        self.fields['heating_pads'].queryset = HeatingPad.objects.filter(Etat='EN_STOCK')
        self.fields['Project'].queryset = firstprojet.objects.filter(statut='attente')

    class Meta:
        model = Rapport
        fields = '__all__'  # Inclut tous les champs du modèle
        labels = {
            'Project': 'le nom du projet',
            'client': 'le client',
            'flexitanks': 'flexitanks',
            'heating_pads': 'heating pads',
        }

class HeatingPadForm (ModelForm):
    def __init__(self, *args, **kwargs):
        super(HeatingPadForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper(self)
    
    
    class Meta:
        model = HeatingPad
        fields = ['DIST','code']  # Inclut tous les champs du modèle
        labels = {
            'DIST': 'le nom du fournisseur',
            'code': 'Numero de serie',
            
        }
        

class FlexitanksForm (ModelForm):
    def __init__(self, *args, **kwargs):
        super(FlexitanksForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper(self)
    
    
    class Meta:
        model = Flexitanks
        fields = ['DIST','code']  # Inclut tous les champs du modèle
        labels = {
            'DIST': 'le nom du fournisseur',
            'code': 'Numero de serie',
            
        }
class ProjectForm(ModelForm):
    def __init__(self, *args, **kwargs):
        super(ProjectForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper(self)
        self.helper.layout = Layout(
            Column(
                'title',
                'email_chef_projet'
            ),
        )

    class Meta:
        model = Project
        fields = ['title','email_chef_projet']
        labels={
            'title':'Nom du projet',
            'email_chef_projet':'Email du chef du projet ',
        }

class firstform(ModelForm):
    def __init__(self, *args, **kwargs):
        super(firstform, self).__init__(*args, **kwargs)
        self.helper = FormHelper(self)
         
    
    class Meta:
        model = firstprojet
        fields = ['nom','TRD']
        labels={
            'nom':'Nom du projet',
            'TRD':'TRD du projet ',
        }
class ArticleVariantForm(ModelForm):
    def __init__(self, *args, **kwargs):
        super(ArticleVariantForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper(self)
        self.helper.layout = Layout(
            Column(
                'article',
                'price',
            ),
        )
    
    def clean_price(self):
        price = self.cleaned_data.get('price')
        if price is not None and price <= 0:
            raise forms.ValidationError('Le prix doit être supérieure à 0.')
        return price
    

    class Meta:
        model = ArticleVariant
        fields ="__all__"
        labels = {
            'article': 'Article ',
            'price': 'Prix',
     
        }


class AttributeForm(ModelForm):

    def __init__(self, *args, **kwargs):
        super(AttributeForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper(self)

    class Meta:
        model = Attribute
        fields = "__all__"


class AttributeValueForm(ModelForm):

    def __init__(self, *args, **kwargs):
        super(AttributeValueForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper(self)
        self.helper.layout = Layout(
            Column('article_variant',
                   'attribute',
                   'value',  
            ),
        )
    class Meta:
        model = AttributeValue
        fields = "__all__"
        labels={
            'article_variant':"variant d'article",
            'attribute':'attribut',
            'value':"valeur d'attribut",
            
        }

class CategoryForm(ModelForm):

    def __init__(self, *args, **kwargs):
        super(CategoryForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper(self)

    class Meta:
        model = Category
        fields = "__all__"
        labels={
            'label': 'Nom de Categorie',
        }


class ArticleForm(ModelForm):

    def __init__(self, *args, **kwargs):
        super(ArticleForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper(self)
        self.helper.layout = Layout(
            Column(
                'label', 'category',
                css_class='form-group col-md-6 mb-0'
            ),
        )

    class Meta:
        model = Article
        fields = ["label", "category"]
        labels = {
            'category': 'Catégorie ',
            'label': "Nom de l'ARTICLE ",
        }




class StockForm(ModelForm):

    def __init__(self, *args, **kwargs):
        super(StockForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper(self)
        self.helper.layout = Layout(
            Column(
                'label',
                'project',
            ),
        )


    class Meta:
        model = Stock
        fields = "__all__"
        labels={
            'label':"Nom Du Site",
            'project':"Projet Rattacher ",
            
        }



class UserProfileForm(ModelForm):

    def __init__(self, *args, **kwargs):
        super(UserProfileForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper(self)

    class Meta:
        model = UserProfile
        fields = "__all__"


