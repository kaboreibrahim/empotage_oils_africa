import os.path
import uuid

from stock_backend import models
from django.db import models
from django_lifecycle import LifecycleModel, hook, AFTER_UPDATE
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes.fields import GenericForeignKey, GenericRelation
from django.core.files.storage import FileSystemStorage
from django.conf import settings
from django.contrib.auth.models import User
from .validators import validate_image_extension
from django.core.validators import  MinValueValidator
from datetime import datetime
# https://django-safedelete.readthedocs.io/en/latest/
from safedelete.models import SafeDeleteModel
from safedelete.config import SOFT_DELETE_CASCADE
# https://django-simple-history.readthedocs.io/en/la
# https://django-simple-history.readthedocs.io/en/latest/
from simple_history.models import HistoricalRecords
from django.utils import timezone

from django.core.exceptions import ValidationError
#import stock_backend.models import dashboard
from datetime import timezone

from django.db import models

imageFs = FileSystemStorage(location=os.path.join(str(settings.BASE_DIR),
                                                  '/media/articles/'))


class firstprojet(LifecycleModel, SafeDeleteModel):
    """
        Classe représentant une stock pour un firstprojet
    """
    _safedelete_policy = SOFT_DELETE_CASCADE
    id = models.UUIDField("ID", primary_key=True, default=uuid.uuid4,
                          editable=False)
    nom = models.CharField(verbose_name="nom",  unique=True,
                             max_length=255, null=False, blank=False)
    TRD = models.CharField(verbose_name="TRD",
                             max_length=255, null=False, blank=False)
    
    STATUT_CHOICES = [
        ('attente', 'attente'),
        ('terminé', 'Terminé'),
        # Ajoutez d'autres statuts si nécessaire
    ]
    date_entre = models.DateTimeField( default=datetime.now)

    statut = models.CharField(verbose_name="Statut", max_length=20, choices=STATUT_CHOICES, default='attente')
    def __str__(self) -> str:    
        return f"{self.nom}" 
    
    



class Flexitanks(LifecycleModel, SafeDeleteModel):
    """
    Classe représentant un flexitank.
    """
    
    ETAT_CHOICES = [
        ('SORTIE', 'SORTIE'),
        ('EN_STOCK', 'EN STOCK'),
    ]
    DIST = [
        ('OILS_of_AFRICA', 'OILS OF AFRICA'),
        ('DHL', 'DHL'),
        ('AUTRE', 'AUTRE'),
    ]
    _safedelete_policy = SOFT_DELETE_CASCADE
    
    id = models.UUIDField("ID", primary_key=True, default=uuid.uuid4, editable=False)
    code = models.CharField(max_length=255, unique=True)
    DIST = models.CharField(max_length=255, choices=DIST, blank=True, null=True)
    etat = models.CharField(max_length=255, choices=ETAT_CHOICES, default='EN_STOCK', blank=True, null=True)
    date_entre = models.DateTimeField(default=datetime.now)
    date_sortie = models.DateTimeField(null=True, blank=True)  # Champ ajouté pour la date de sortie

    def __str__(self):
        return f" {self.code} - {self.DIST} "
    
class HeatingPad(LifecycleModel,SafeDeleteModel):
    
    """
    classe représentant un heating pad
    """
    DIST = [
        ('OILS_of_AFRICA', 'OILS OF AFRICA'),
        ('DHL', 'DHL'),
        ('AUTRE', 'AUTRE'),
    ]
    ETAT = [
        ('SORTIE', 'SORTIE'),
        ('EN_STOCK', 'EN STOCK'),
    ]
    _safedelete_policy = SOFT_DELETE_CASCADE
    id = models.UUIDField("ID", primary_key=True, default=uuid.uuid4,
                          editable=False)
    DIST = models.CharField(max_length=255, choices=DIST, blank=True, null=True)

    code = models.CharField(max_length=255, blank=False, null=False,unique=True)
    Etat = models.CharField(max_length=255, choices=ETAT, blank=True, null=True ,default='EN_STOCK')

    date_entre = models.DateTimeField( default=datetime.now)
    date_sortie = models.DateTimeField(blank=True, null=True)
   
    def __str__(self):
        return f"  {self.code}-{self.DIST} "


class Project(LifecycleModel, SafeDeleteModel):
    """
    classe représentant un Projet 
    """
    _safedelete_policy = SOFT_DELETE_CASCADE
    id = models.UUIDField("ID", primary_key=True, default=uuid.uuid4,
                          editable=False)
    title = models.CharField(verbose_name="title",
                             max_length=255, null=False, blank=False, unique=True)
    history = HistoricalRecords(table_name='project_history',
        
                        history_id_field=models.UUIDField(default=uuid.uuid4))
    email_chef_projet = models.EmailField("Email", blank=True, null=True)

    class Meta:
        db_table = 'projects'
        verbose_name = "Projet"
        verbose_name_plural = "Projets"
        ordering = ['title']

    def __str__(self):
        return str(self.title)

    @hook(AFTER_UPDATE, when='title')
    def email_banned_user(self):
        print("Send Email")



class UserProfile(models.Model):
    """
    Classe représentant un Profil utilisateur
    """
    ROLES = [
        ('STGR', 'Stagiaire Logistique'),
        ('USER', 'Agent Logistique'),
        ('RESP', 'Responsable Logistique'),
        ('AGENT', 'cite externe'),
    ]
    _safedelete_policy = SOFT_DELETE_CASCADE
    id = models.UUIDField("ID", primary_key=True, default=uuid.uuid4, editable=False)
    user = models.OneToOneField(User, verbose_name="Utilisateur", null=True, blank=True, on_delete=models.CASCADE, related_name="user_profile")
    role = models.CharField(max_length=255, choices=ROLES, blank=True, null=True)
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="user_profiles", blank=True, null=True) # Nouveau champ projet
    history = HistoricalRecords(table_name='user_profile_history', history_id_field=models.UUIDField(default=uuid.uuid4))

    class Meta:
        db_table = 'users_profiles'
        verbose_name = "Profils utilisateur"
        verbose_name_plural = "Profils utilisateurs"
        ordering = ['user', 'role']
    def __str__(self) -> str:    
        return f"{self.user} {self.project}"  

   

class Category(LifecycleModel, SafeDeleteModel):
    """
        Classe représentant une catégorie d'un article
    """
    _safedelete_policy = SOFT_DELETE_CASCADE
    id = models.UUIDField("ID", primary_key=True, default=uuid.uuid4,
                          editable=False)
    label = models.CharField(verbose_name="Libellé",
                             max_length=255, null=False, blank=False, unique=True)
    history = HistoricalRecords(table_name='category_history',
                                history_id_field=models.UUIDField(default=uuid.uuid4))

    class Meta:
        db_table = 'category'
        verbose_name = "Catégorie"
        verbose_name_plural = "Catégories"
        ordering = ['label']

    def __str__(self):
        return str(self.label)


class Stock(LifecycleModel, SafeDeleteModel):
    """
        Classe représentant une stock pour un projet
    """
    _safedelete_policy = SOFT_DELETE_CASCADE
    id = models.UUIDField("ID", primary_key=True, default=uuid.uuid4,
                          editable=False)
    label = models.CharField(verbose_name="label",
                             max_length=255, null=False, blank=False)
    project = models.ForeignKey(
        Project, on_delete=models.CASCADE, related_name="project_stocks")
    history = HistoricalRecords(table_name='stock_history',
                                history_id_field=models.UUIDField(default=uuid.uuid4))

    class Meta:
        db_table = 'stocks'
        verbose_name = "Stock"
        verbose_name_plural = "Stocks"
        ordering = ['label', 'project']

    def __str__(self) -> str:    
        return f"{self.label}"  
    


class Attribute(LifecycleModel, SafeDeleteModel):
    """
        Classe représentant un attribut d'article
    """
    _safedelete_policy = SOFT_DELETE_CASCADE
    id = models.UUIDField("ID", primary_key=True, default=uuid.uuid4,
                          editable=False)
    label = models.CharField(max_length=255, null=True, unique=True)
    history = HistoricalRecords(table_name='attributes_history',
                                history_id_field=models.UUIDField(default=uuid.uuid4))

    class Meta:
        db_table = 'attributs'
        verbose_name = "Attribut"
        verbose_name_plural = "Attributs"
        ordering = ['label']

    def __str__(self):
        return f"{self.label}"

class Fournisseurs(LifecycleModel, SafeDeleteModel):
    """
        Classe représentant un fournisseur
    """
    _safedelete_policy = SOFT_DELETE_CASCADE
    id = models.UUIDField("ID", primary_key=True, default=uuid.uuid4,
                          editable=False)
    label = models.CharField(verbose_name="Libellé",
                             max_length=255, null=False, blank=False, unique=True)
    history = HistoricalRecords(table_name='fournisseurs_history',
                                history_id_field=models.UUIDField(default=uuid.uuid4))

    class Meta:
        db_table = 'fournisseur'
        verbose_name = "Fournisseur"
        verbose_name_plural = "Fournisseurs"
        ordering = ['label']

    def __str__(self):
        return str(self.label)
    
    
class Transfer(LifecycleModel, SafeDeleteModel):
    """
        Classe représentant un transfert d'article 
    """
    _safedelete_policy = SOFT_DELETE_CASCADE
    id = models.UUIDField("ID", primary_key=True, default=uuid.uuid4,
                          editable=False)
    origin_of_transfer = models.ForeignKey(
        Stock, on_delete=models.CASCADE, blank=True, null=True, related_name="exit_transfers")
    destination_of_transfer = models.ForeignKey(
        Stock, on_delete=models.CASCADE, blank=True, null=True, related_name="entrances_transfers")
    serial_lot_of_item = models.ForeignKey(
        'ArticleSerialLot', on_delete=models.CASCADE, blank=True, null=True)
    quantity = models.IntegerField()
    Flexitanks = models.ManyToManyField(Flexitanks, blank=True)
    heating_pad = models.ManyToManyField(HeatingPad, blank=True)
    nom_fournissuer = models.ForeignKey(
        'Fournisseurs', on_delete=models.CASCADE, blank=True, null=True)
    projet = models.ForeignKey(
        'firstprojet', on_delete=models.CASCADE, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    history = HistoricalRecords(table_name='transfer_history',
                                history_id_field=models.UUIDField(default=uuid.uuid4))                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
    
    class Meta:
        db_table = 'transfers'
        verbose_name = "Transfert"
        verbose_name_plural = "Transferts"
        ordering = ['serial_lot_of_item', 'origin_of_transfer']
    
    def __str__(self) -> str:
        return f"{self.origin_of_transfer}:{self.destination_of_transfer}:{self.serial_lot_of_item} : {self.quantity}"
    
   

    def clean(self):
        
        print(self.serial_lot_of_item.pk)
        
        # Récupérer les stocks associés au projet "FOURNISSEURS"
        projet_affect = Stock.objects.filter(project__title="FOURNISSEURS")
        
        # Récupérer le fournisseur
        provider = Stock.objects.filter(label="FOURNISSEURS").first()
        
        
        if self.origin_of_transfer == provider:
            
            pass  # Ne faites rien dans ce cas, ou effectuez d'autres opérations si nécessaire
        else:
            
            serial_lot_of_item=self.serial_lot_of_item.pk
            print(serial_lot_of_item)
            destination_of_transfer=self.destination_of_transfer.pk
            print(destination_of_transfer)
            origin_of_transfer=self.origin_of_transfer.pk
            print(origin_of_transfer)
            lines_inp=[]  
            # Get input and output transfer lines
            lines_inp = Transfer.objects.filter(
                serial_lot_of_item=serial_lot_of_item,
                origin_of_transfer=provider.id,
                destination_of_transfer=origin_of_transfer
            
            ).all()
            lines_out=[]
            lines_out = Transfer.objects.filter(
                serial_lot_of_item=serial_lot_of_item,
                origin_of_transfer=origin_of_transfer
                ).all()
            
            print(f"la ligne des entre :{lines_inp}")
            print(f"la ligne des sortie :{lines_out}")
        
        
            # Calculate the sum of input and output quantities
            sum_lines_inp = lines_inp.aggregate(models.Sum("quantity"))["quantity__sum"] or 0
            sum_lines_out = lines_out.aggregate(models.Sum("quantity"))["quantity__sum"] or 0

            print(f"La somme des entrées : {sum_lines_inp}")
            print(f"La somme des sorties : {sum_lines_out}")

            # Calculate the remaining quantity
            real_quantity = sum_lines_inp - sum_lines_out
            
            print(f"La quantité restante : {real_quantity}")   
      
            date_actuelle = datetime.now().replace(tzinfo=timezone.utc)
            Date_expire = self.serial_lot_of_item.expiry_date
            
            # Vérification si la date d'expiration est présente
            if Date_expire is not None:
                date_actuelle = date_actuelle.replace(minute=0, second=0, microsecond=0)
                Date_expire = Date_expire.replace(minute=0, second=0, microsecond=0)

                    # Calcul de la différence entre les deux dates
                difference = Date_expire - date_actuelle
                    

                    # Formatage des dates
                date_actuelle_format = date_actuelle.strftime('%Y-%m-%d-%H:%M')
                Date_expire_format = Date_expire.strftime('%Y-%m-%d%H:%M')

                    
                if difference.days<=0:
                    raise ValidationError({"quantity": ["PRODUIT PERIMER"]})
                else:
                    pass
                    
            if self.origin_of_transfer != provider and self.quantity > real_quantity  :
                raise ValidationError({"quantity": ["La quantité demandée dépasse la quantité disponible."]})
            # Check if the destination stock is the same as the origin stock
            if self.origin_of_transfer == self.destination_of_transfer:
                raise ValidationError({"destination_of_transfer": ["La destination ne peut pas être le même stock que l'origine."]})
            if self.quantity is not None and self.quantity <= 0:
                raise ValidationError('La quantité doit être supérieure à 0.')
    
    def save(self, *args, **kwargs):
        self.clean()
        super().save(*args, **kwargs)
  
  
  
    
class Image(LifecycleModel, SafeDeleteModel):
    """
        Classe représentant une image 
    """
    _safedelete_policy = SOFT_DELETE_CASCADE
    id = models.UUIDField("ID", primary_key=True, default=uuid.uuid4,
                          editable=False)
    image = models.ImageField(storage=imageFs, name="image", validators=[
        validate_image_extension])
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.UUIDField("object_id", default=uuid.uuid4,
                                 editable=False)
    content_object = GenericForeignKey('content_type', 'object_id')
    history = HistoricalRecords(table_name='image_history',
                                history_id_field=models.UUIDField(default=uuid.uuid4))

    class Meta:
        db_table = 'images'
        verbose_name = "Image"
        verbose_name_plural = "Images"

    def __str__(self):
        return str(self.image)


class Article(LifecycleModel, SafeDeleteModel):
    """
        Classe représentant un article
    """
    _safedelete_policy = SOFT_DELETE_CASCADE
    id = models.UUIDField("ID", primary_key=True, default=uuid.uuid4,
                          editable=False)
    label = models.CharField(max_length=255, null=False,
                             blank=False, unique=True)
    category = models.ForeignKey(
        Category, blank=True, null=True, on_delete=models.CASCADE, related_name="articles")
    variants = models.ManyToManyField(
        'ArticleVariant', blank=True, related_name="variants_of_article")
    history = HistoricalRecords(table_name='article_history',
                                history_id_field=models.UUIDField(default=uuid.uuid4))

    class Meta:
        db_table = 'articles'
        verbose_name = "Article"
        verbose_name_plural = "Articles"

    def __str__(self):
        return str(self.label)


class ArticleVariant(LifecycleModel, SafeDeleteModel):
    """
        Classe représentant une instance de variante d'un article
    """
    _safedelete_policy = SOFT_DELETE_CASCADE
    id = models.UUIDField("ID", primary_key=True, default=uuid.uuid4,
                          editable=False)
    article = models.ForeignKey(
        Article, on_delete=models.CASCADE, blank=False, null=False, related_name="variants_of_article")
    price = models.IntegerField(
        null=True, default=0, blank=False, validators=[MinValueValidator(0)])
    attributes = models.ManyToManyField(
        Attribute, through='AttributeValue', blank=True)
    history = HistoricalRecords(table_name='articles_variants_history',
                                history_id_field=models.UUIDField(default=uuid.uuid4))

    class Meta:
        db_table = 'variants'
        verbose_name = "Variant d'un article"
        verbose_name_plural = "Variantes des articles"

    @property
    def longname(self):
        long_name = ""
        for attribute_value in self.attributes_values.all():
            # long_name = long_name + f"{attribute.label} : "
            long_name = long_name + f"{attribute_value.value} "
        return f"{self.article} {long_name}"

    def __str__(self):
        return self.longname


class AttributeValue(LifecycleModel, SafeDeleteModel):
    """
            Classe représentant une de valeur d'un attribut
        """
    _safedelete_policy = SOFT_DELETE_CASCADE
    id = models.UUIDField("ID", primary_key=True, default=uuid.uuid4,
                          editable=False)
    article_variant = models.ForeignKey(
        ArticleVariant, on_delete=models.CASCADE, blank=False, null=False, related_name="attributes_values")
    attribute = models.ForeignKey(
        Attribute, on_delete=models.CASCADE, blank=False, null=False, related_name="attributes_values")
    value = models.CharField(max_length=255, null=True)
    history = HistoricalRecords(table_name='attributes_values_history',
                                history_id_field=models.UUIDField(default=uuid.uuid4))

    @property
    def shortname(self):
        return f"{self.value}"

    @property
    def longname(self):
        return f"{self.article_variant.article} - {self.value}"

    class Meta:
        db_table = 'attributes_values'
        verbose_name = "Valeurs d'attributs"
        verbose_name_plural = "Valeurs des attributs"
        ordering = ['value']
        unique_together = ["article_variant", "attribute", "value"]

    def __str__(self):
        return f"{self.longname}"


class ArticleSerialLot(LifecycleModel, SafeDeleteModel):
    """
        Classe représentant un numéro de série d'une variante d'article
    """
    _safedelete_policy = SOFT_DELETE_CASCADE
    id = models.UUIDField("ID", primary_key=True, default=uuid.uuid4,
                          editable=False)
    code = models.CharField(max_length=255, blank=False, null=False,unique=True)
    expiry_date = models.DateTimeField(blank=True, null=True)
    article_variant = models.ForeignKey(
        ArticleVariant, on_delete=models.CASCADE, blank=True, null=True)
    transfers = GenericRelation(Transfer)
    history = HistoricalRecords(table_name='article_serial_lot_history',
                                history_id_field=models.UUIDField(default=uuid.uuid4))
    date_created_at = models.DateTimeField( default=datetime.now)
    
    class Meta:
        db_table = 'article_serial_lots'
        verbose_name = "Numéro de série des articles"
        verbose_name_plural = "Numéros de série des articles"

    def __str__(self) -> str:
        return f"{self.article_variant} "  
  
class Rapport(LifecycleModel, SafeDeleteModel):
    """
    Classe représentant un rapport
    """
    _safedelete_policy = SOFT_DELETE_CASCADE

    id = models.UUIDField(
         "ID",
         primary_key=True,
         default=uuid.uuid4,
         editable=False
    )

    Project = models.ForeignKey(
         'firstprojet',
         on_delete=models.CASCADE,
         verbose_name="Projet"
     )

    client = models.ForeignKey(
         'Stock',
         on_delete=models.CASCADE,
         verbose_name="Client"
     )

    Date_creation_rapport = models.DateTimeField(default=datetime.now)

    flexitanks = models.ManyToManyField(Flexitanks, verbose_name="Flexitanks", related_name='rapports')
    heating_pads = models.ManyToManyField(HeatingPad, verbose_name="Heating Pads", related_name='rapports', blank=True)

    commentaire=models.CharField(blank=True, max_length=255)

    class Meta:
        verbose_name = "Rapport"
        verbose_name_plural = "Rapports"
        ordering = ['-Date_creation_rapport']

    def __str__(self):
        return f"Rapport {self.id} - {self.Project}"