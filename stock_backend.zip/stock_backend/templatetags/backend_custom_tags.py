from django import template
from django.db.models import Sum
from regex import A

from stock_backend.models import Article, AttributeValue

register = template.Library()


@register.inclusion_tag("pages/attributes_values/attributes_template.html")
def show_article_attributes_values(article_id):
    article = Article.objects.get(pk=article_id)
    attribute_values = AttributeValue.objects.filter(
        article=article).all()
    print(
        f"show_article_attributes_values : {article} => {len(attribute_values)}")
    return {'attribute_values': attribute_values}
