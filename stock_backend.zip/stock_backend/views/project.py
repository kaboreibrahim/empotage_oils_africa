from django.http import HttpRequest, HttpResponseRedirect
from django.urls import reverse, reverse_lazy
from stock_backend.forms import ProjectForm
from stock_backend.models import Project
from django.views.generic.edit import CreateView, DeleteView, UpdateView
from django.views.generic import ListView, DetailView
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from braces.views import FormMessagesMixin
from django.shortcuts import render
from django.contrib import messages

@method_decorator(login_required, name='dispatch')
class ProjectListView(ListView):
    """
        vue d'affichage de la liste des projects
    """
    model = Project
    context_object_name = 'project_list'
    template_name = "pages/projects/list.html"

    def get_queryset(self):
        queryset = Project.objects.all()
        return queryset

@method_decorator(login_required, name='dispatch')
class ProjectCreateView(FormMessagesMixin, CreateView):
    """
      Vue de création d'un project
    """
    model = Project
    form_class = ProjectForm
    template_name = "pages/projects/create.html"
    success_url = reverse_lazy('project-list')
    form_invalid_message = "Oups, quelque chose s'est mal passé!"

    def get_form_valid_message(self):
        return u"{0} crée avec succés!".format(self.object.title)

    def post(self, request: HttpRequest, *args, **kwargs):
        # Look up the author we're interested in.
        print(f"Project Post : {request.POST}")
        # Actually record interest somehow here!
        form = ProjectForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('project-list'))
        else:
            print(f"Project form errors : {form.errors}")
            return HttpResponseRedirect(reverse('project-new'), {"form": form})

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        context['form'] = ProjectForm
        context['method'] = "post"
        return context


@method_decorator(login_required, name='dispatch')
class ProjectUpdateView(FormMessagesMixin, UpdateView):
    """
      vue de mise à jour d'un project
    """
    model = Project
    form_class = ProjectForm
    template_name = "pages/projects/create.html"
    success_url = reverse_lazy('project-list')
    form_invalid_message = "Oups, quelque chose s'est mal passé!"

    def get_form_valid_message(self):
        return u" Modification effectueé avec succès!"

    # Recupère l'identifiant de l'objet caché dans le formulaire pour modifier le bon objet
    def get_object(self, **kwargs):
        print("Project Update data : {}".format(self.request.body))
        return Project.objects.get(pk=self.request.POST.get('pk'))

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        context['method'] = "put"
        return context


@method_decorator(login_required, name='dispatch')
class ProjectDeleteView(DeleteView):
    model = Project
    success_url = reverse_lazy('project-list')


@method_decorator(login_required, name='dispatch')
class ProjectDetailView(DetailView):
    """
        Vue d'affichage d'un project
    """
    model = Project
    template_name = "pages/projects/create.html"

    def get_context_data(self, **kwargs):
        """
            Surchage l'objet context
        """
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        obj = self.get_object()
        print(f"Detail request : {obj.pk}")
        context['form'] = ProjectForm(instance=obj)
        context['object'] = obj
        context['method'] = "put"
        return context
