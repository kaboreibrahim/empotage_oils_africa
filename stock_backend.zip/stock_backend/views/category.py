from django.http import HttpRequest, HttpResponseRedirect
from django.urls import reverse, reverse_lazy
from stock_backend.forms import CategoryForm
from stock_backend.models import Category
from django.views.generic.edit import CreateView, DeleteView, UpdateView
from django.views.generic import ListView, DetailView
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from braces.views import FormMessagesMixin
from django.contrib import messages


@method_decorator(login_required, name='dispatch')
class CategoryListView(ListView):
    """
        vue d'affichage de la liste des categorys
    """
    model = Category
    context_object_name = 'category_list'
    template_name = "pages/categories/list.html"

    def get_queryset(self):
        queryset = Category.objects.all()
        return queryset


@method_decorator(login_required, name='dispatch')
class CategoryCreateView(FormMessagesMixin, CreateView):
    """
      Vue de création d'un category
    """
    model = Category
    form_class = CategoryForm
    template_name = "pages/categories/create.html"
    success_url = reverse_lazy('category-list')
    form_invalid_message = "Oups, quelque chose s'est mal passé!"

    def get_form_valid_message(self):
        return u"{0} crée avec succès!".format(self.object.label)

    def post(self, request: HttpRequest, *args, **kwargs):
        # Look up the author we're interested in.
        print(f"Category Post : {request.POST}")
        # Actually record interest somehow here!
        form = CategoryForm(request.POST)
        if form.is_valid():
            form.save()
            messages.add_message(request,messages.SUCCESS," ENREGISTREMENT  LA CATEGORIE ")

            return HttpResponseRedirect(reverse('category-list'), {"form": form})
        else:
            print(f"Category form errors : {form.errors}")
            messages.add_message(request,messages.ERROR," ERREUR !!! LA CATEGORIE ENTRE EXISTE DEJA " )

            return HttpResponseRedirect(reverse('category-new'), {"form": form})

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        context['form'] = CategoryForm
        context['method'] = "post"
        return context


@method_decorator(login_required, name='dispatch')
class CategoryUpdateView(FormMessagesMixin, UpdateView):
    """
      vue de mise à jour d'un category
    """
    model = Category
    form_class = CategoryForm
    template_name = "pages/categories/create.html"
    success_url = reverse_lazy('category-list')
    form_invalid_message = "Oups, quelque chose s'est mal passé!"

    def get_form_valid_message(self):
        return u"Modification effectueé avec succès!"
    
    # Recupère l'identifiant de l'objet caché dans le formulaire pour modifier le bon objet
    def get_object(self, **kwargs):
        print("Project Update data : {}".format(self.request.body))
        return Category.objects.get(pk=self.request.POST.get('pk'))

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        context['method'] = "put"
        return context


@method_decorator(login_required, name='dispatch')
class CategoryDeleteView(DeleteView):
    model = Category
    success_url = reverse_lazy('category-list')


@method_decorator(login_required, name='dispatch')
class CategoryDetailView(DetailView):
    """
        Vue d'affichage d'un category
    """
    model = Category
    template_name = "pages/categories/create.html"

    def get_context_data(self, **kwargs):
        """
            Surchage l'objet context
        """
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        obj = self.get_object()
        print(f"Detail request : {obj.pk}")
        context['form'] = CategoryForm(instance=obj)
        context['object'] = obj
        context['method'] = "put"
        return context
