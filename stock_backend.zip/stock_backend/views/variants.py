from django.http import HttpRequest, HttpResponseRedirect
from django.shortcuts import redirect
from django.urls import reverse, reverse_lazy
from stock_backend.forms import ArticleVariant, ArticleVariantForm, AttributeValueForm
from stock_backend.models import Article, AttributeValue
from django.views.generic.edit import CreateView, DeleteView, UpdateView
from django.views.generic import ListView, DetailView
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.forms import inlineformset_factory, modelformset_factory


@method_decorator(login_required, name='dispatch')
class ArticleVariantListView(ListView):
    """
            vue d'affichage de la liste des variants des articles
    """
    model = ArticleVariant
    template_name = "pages/variants/list.html"

    
    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        article = Article.objects.get(pk=self.kwargs['article'])
        context['article'] = article
        context['variants_list'] = ArticleVariant.objects.filter(
            article=self.kwargs['article']
        )
        return context


@method_decorator(login_required, name='dispatch')
class ArticleVariantCreateView(CreateView):
    """
            vue de création d'articles
    """
    model = ArticleVariant
    form_class = ArticleVariantForm
    template_name = "pages/variants/create.html"
    success_url = reverse_lazy('article-variants-list')

    def post(self, request: HttpRequest, *args, **kwargs):
        # Look up the author we're interested in.
        data = request.POST.copy()
        print(f"Article Variant Post : {data}")
        attribute_value_formset = modelformset_factory(
            AttributeValue, AttributeValueForm, extra=1)
        formset = attribute_value_formset(data, prefix='attributes')
        # Actually record interest somehow here!
        form = ArticleVariantForm(data)
        article = Article.objects.get(pk=data.get('article'))
        print(f"Article : {article}")
        if form.is_valid():
            article_variant = ArticleVariant.objects.create(article=article, price=data.get('price'))
            for obj in formset:
                if obj.is_valid():
                    # print(form.cleaned_data)
                    obj.article_variant = article_variant
                    obj.save()
            else:
                print(f"Article Variant Attribute formset errors : {formset.non_form_errors()}")
                print(f"Article Variant Attribute formset errors : {formset.errors}")
            return redirect('article-variants-list', data.get("article"))
        else:
            print(f"Article Variant form errors : {form.non_field_errors()}")
            print(f"Article Variant form errors : {form.errors}")
            return redirect('article-variants-list', data.get("article"))

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        article = Article.objects.get(pk=self.kwargs['article'])
        form = ArticleVariantForm(
            initial={'article': article}
        )
        attribute_value_formset = modelformset_factory(
            AttributeValue, AttributeValueForm, fields=('article_variant', 'attribute', 'value'), extra=1)
        formset = attribute_value_formset(
            queryset=AttributeValue.objects.none(),
            prefix="attributes"
        )
        form.fields['article'].disabled = True
        field = form.fields['article']
        field.widget = field.hidden_widget()
        # Add in the publisher
        context['form'] = form
        context['formset'] = formset
        context['article'] = article
        context['method'] = "post"
        return context


@method_decorator(login_required, name='dispatch')
class ArticleVariantUpdateView(UpdateView):
    """
        vue de mise à jour d'un article
    """
    model = ArticleVariant
    form_class = ArticleVariantForm
    template_name = "pages/variants/create.html"
    success_url = reverse_lazy('article-variants-list')
    
    


    # Recupère l'identifiant de l'objet caché dans le formulaire pour modifier le bon objet
    def get_object(self, **kwargs):
        print("ArticleVariant Update data : {}".format(self.request.body))
        return AttributeValue.objects.get(pk=self.request.POST.get('pk'))

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        context['method'] = "put"
        return context


@method_decorator(login_required, name='dispatch')
class ArticleVariantDeleteView(DeleteView):
    model = ArticleVariant
    success_url = reverse_lazy('article-variants-list')


@method_decorator(login_required, name='dispatch')
class ArticleVariantDetailView(DetailView):
    """
        vue d'affichage d'un article
    """
    model = ArticleVariant
    template_name = "pages/variants/create.html"

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        obj = self.get_object()
        print(f"ArticleVariant Detail request : {obj.pk}")
        attribute_value_form_set = modelformset_factory(
            AttributeValue, AttributeValueForm, fields=('article_variant', 'attribute', 'value'), extra=1)
        # attribute_value_form_set = inlineformset_factory(parent_model=Article,
        #                                               model=AttributeValue, form=AttributeValueForm, fields=('attribute', 'value'), extra=1)
        queryset = AttributeValue.objects.filter(article_variant=obj).all()
        formset = attribute_value_form_set(
            queryset=queryset,
            prefix="attributes"
        )
        print(f"Form type: {type(formset)}")
        context['form'] = AttributeValueForm(instance=obj)
        context['formset'] = formset
        context['object'] = obj
        context['method'] = "put"
        return context
