from collections import defaultdict
from django.db.models import Sum
from stock_backend.models import Transfer,Project,ArticleSerialLot
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from django.core.mail import send_mail
from django.contrib import messages
from django.utils import timezone
from datetime import datetime
from django.db.models import Sum


@login_required
def indicateur(request):
    messages.add_message(request, messages.SUCCESS, "Bienvenue %s sur  vos indicateur de gestion " % request.user.username)

    # Récupérer le profil utilisateur et le projet
    user_profile = request.user.user_profile
    project = user_profile.project

    # Filtrer les transferts en fonction des permissions de l'utilisateur
    if request.user.is_superuser:
        all_transfers = Transfer.objects.all()
    else:
        all_transfers = Transfer.objects.filter(destination_of_transfer__project=project)

    # Initialiser defaultdict pour regrouper les transferts
    transfer_groups = defaultdict(list)
    unique_entries = set()

    for transfer in all_transfers:
        serial_lot_of_item = transfer.serial_lot_of_item
        destination_of_transfer = transfer.destination_of_transfer

        # Vérifier si l'entrée a déjà été traitée
        if (serial_lot_of_item, destination_of_transfer) in unique_entries:
            continue

        # Récupérer les transferts liés à l'entrée actuelle
        transfers_inp = Transfer.objects.filter(
            serial_lot_of_item=serial_lot_of_item,
            origin_of_transfer__label="FOURNISSEURS",  # Supposant que le filtrage par étiquette est correct
            destination_of_transfer=destination_of_transfer,
        )

        transfers_out = Transfer.objects.filter(
            serial_lot_of_item=serial_lot_of_item,
            origin_of_transfer=destination_of_transfer,
        )

        # Calculer les quantités totales
        total_quantity_out = transfers_out.aggregate(total_quantity_out=Sum('quantity'))['total_quantity_out'] or 0
        total_quantity_inp = transfers_inp.aggregate(total_quantity_inp=Sum('quantity'))['total_quantity_inp'] or 0
        total_quantity_rest = total_quantity_inp - total_quantity_out

        # Inclure uniquement les entrées où au moins l'une des quantités est non nulle
        if any([total_quantity_out, total_quantity_inp, total_quantity_rest]):
            transfer_groups[destination_of_transfer].append({
                'total_quantity_out': total_quantity_out,
                'total_quantity_inp': total_quantity_inp,
                'total_quantity_rest': total_quantity_rest,
                'transfers_inp': transfers_inp,
                'transfers_out': transfers_out,
                'serial_lot_of_item': serial_lot_of_item,
                'destination_name': destination_of_transfer.label  # Ajouter le nom réel de la destination
            })
        
        # Marquer l'entrée comme traitée
        unique_entries.add((serial_lot_of_item, destination_of_transfer))
    
    
                
    return render(request, "index.html", {
        'transfer_groups': dict(transfer_groups),
        'all_transfers': all_transfers,
       
    })
