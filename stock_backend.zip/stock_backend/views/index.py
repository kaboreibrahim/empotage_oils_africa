from django.core.mail import send_mail
from django.http import HttpRequest
from django.utils import timezone
from datetime import datetime
from django.db.models import Sum
from collections import defaultdict
from django.contrib import messages
from django.shortcuts import render
from stock_backend.models import Transfer, Stock, ArticleSerialLot, Project, Category, Article
from django.contrib.auth.decorators import login_required
from django.template.loader import render_to_string
import requests
from django.contrib.auth import get_user_model
from django.db.models import Count
from django.utils import timezone
from datetime import timedelta
import calendar
import locale
import json
from django.utils import timezone

# Fonction d'envoi de mail pour le stock d'alerte
def send_stock_alert_email(transfer_groups, request):
    message_global = "Alerte de stock :\n"
    email_sent = False

    for transfer_destination, transfer_entries in transfer_groups.items():
        for transfer_entry in transfer_entries:
            if transfer_entry['total_quantity_rest'] <= 5:
                message_global += f"\n Le stock du produit {transfer_entry['serial_lot_of_item']} pour le Projet {transfer_destination} est presque épuisé. Veuillez envisager de procéder à un réapprovisionnement."

                projets_correspondants = Project.objects.filter(title=transfer_destination)
                if projets_correspondants.exists():
                    email_chef_projet = projets_correspondants.first().email_chef_projet
                    sujet = f"Alerte de stock épuisé pour le projet {transfer_destination}"
                    send_mail(
                        sujet,
                        message_global,
                        'ibrahimkabore025@gmail.com',
                        [email_chef_projet, 'ibrahimkabore025@gmail.com'],
                        fail_silently=False,
                    )
                    email_sent = True
                else:
                    messages.add_message(request, messages.WARNING, f'Le projet {transfer_destination} semble ne pas exister dans la base de données.')
    
    return email_sent

def send_expired_articles_email(request):
    current_datetime = datetime.now()
    lots_serial_expires = ArticleSerialLot.objects.filter(expiry_date__lte=current_datetime)
    email_sent = False

    if lots_serial_expires.exists():
        sujet = "Articles expirés"
        message = "Liste des articles expirés :\n"

        for lot_serial in lots_serial_expires:
            message += f" -\nArticle : {lot_serial.article_variant}, a expiré à la date du : {lot_serial.expiry_date}"

        send_mail(
            sujet,
            message,
            'ibrahimkabore025@gmail.com',
            ['ibrahimkabore025@gmail.com', 'kaboremessi@gmail.com'],
            fail_silently=False,
        )
        email_sent = True

    return email_sent

@login_required
def index(request):
    data_json = {} 
    categories = Category.objects.all()
    data = []
    for category in categories:
        article_count = category.articles.count()
        data.append({
            'label': category.label,
            'value': article_count
        })

    
        data_json=json.dumps(data)  # Convertir les données en JSON pour le template
        print(data_json)

    # Définir le début et la fin du mois en cours
    today = timezone.now()
    start_of_month = today.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    end_of_month = start_of_month.replace(
        day=1, month=start_of_month.month % 12 + 1, hour=0, minute=0, second=0, microsecond=0
    ) - timedelta(days=1)

    # Filtrer les ArticleSerialLot qui expirent dans le mois en cours
    articles_expiring_this_month = ArticleSerialLot.objects.filter(
        expiry_date__gte=start_of_month, expiry_date__lte=end_of_month
    )
    
       

    # Définir la locale en français
    locale.setlocale(locale.LC_TIME, 'fr_FR.UTF-8')

    user_profile = request.user.user_profile
    project = user_profile.project

    
    # Obtenir la date actuelle
    today = timezone.now()

    # Obtenir le premier et le dernier jour du mois en cours
    first_day_of_month = today.replace(day=1)
    last_day_of_month = (first_day_of_month + timedelta(days=32)).replace(day=1) - timedelta(days=1)

    # Filtrer les transferts  entrant et compter
    transfers_count_input = Transfer.objects.filter(
        origin_of_transfer__label="FOURNISSEURS",
        created_at__date__gte=first_day_of_month,
        created_at__date__lte=last_day_of_month
    ).count()

    # Filtrer les transferts  sortant et compter
    transfers_count_out = Transfer.objects.filter(
        created_at__gte=first_day_of_month,
        created_at__lt=last_day_of_month
    ).count()

    transfert_sortant=transfers_count_out - transfers_count_input
    total_transfer_week=transfers_count_input+transfert_sortant
    # Obtenir le nom du mois en cours en français
    current_month_name = today.strftime('%B')

    # Afficher le nombre de transferts et le mois en cours
    print(f"Nombre de transferts entrant   {current_month_name} : {transfers_count_input}")
    print(f"Nombre de transferts sortant   {current_month_name} : {transfert_sortant}")
    
    if request.user.is_superuser:
        all_transfers = Transfer.objects.all()
    else:
        all_transfers = Transfer.objects.filter(destination_of_transfer__project=project)

    transfer_groups = defaultdict(list)
    unique_entries = set()

    for transfer in all_transfers:
        serial_lot_of_item = transfer.serial_lot_of_item
        destination_of_transfer = transfer.destination_of_transfer

        if (serial_lot_of_item, destination_of_transfer) in unique_entries:
            continue

        provider = Stock.objects.filter(label="FOURNISSEURS").first()
        transfers_inp = Transfer.objects.filter(
            serial_lot_of_item=serial_lot_of_item,
            origin_of_transfer=provider,
            destination_of_transfer=destination_of_transfer,
        )

        transfers_out = Transfer.objects.filter(
            serial_lot_of_item=serial_lot_of_item,
            origin_of_transfer=destination_of_transfer,
        )

        total_quantity_out = transfers_out.aggregate(total_quantity_out=Sum('quantity'))['total_quantity_out'] or 0
        total_quantity_inp = transfers_inp.aggregate(total_quantity_inp=Sum('quantity'))['total_quantity_inp'] or 0

        total_quantity_rest = total_quantity_inp - total_quantity_out

        if total_quantity_out != 0 or total_quantity_inp != 0 or total_quantity_rest != 0:
            transfer_groups[destination_of_transfer].append({
                'total_quantity_out': total_quantity_out,
                'total_quantity_inp': total_quantity_inp,
                'total_quantity_rest': total_quantity_rest,
                'transfers_inp': transfers_inp,
                'transfers_out': transfers_out,
                'serial_lot_of_item': serial_lot_of_item,
                
            })

        unique_entries.add((serial_lot_of_item, destination_of_transfer))

        # Get the current time in UTC
        current_datetime = timezone.now()  # No need to replace tzinfo

        # Query for lots that are expired
        lots_serial_expires = ArticleSerialLot.objects.filter(expiry_date__lte=current_datetime)

    try:
        requests.get('https://www.google.com', timeout=5)
    except requests.ConnectionError:
        messages.add_message(request, messages.ERROR, "Problème de connexion. Impossible d'envoyer les e-mails pour le rapport journalier. Veuillez réessayer plus tard.")
        return render(request, "index.html", {
            'transfer_groups': dict(transfer_groups),
            'all_transfers': all_transfers,
            'current_month_name':current_month_name,
            'transfers_count_input':transfers_count_input,
            'transfert_sortant':transfert_sortant,
            'total_transfer_week':total_transfer_week,
            'articles_expiring_this_month': articles_expiring_this_month,
            'data_json':data_json,
            
        })

    if not request.session.get('functions_executed', False):
        messages.add_message(request, messages.SUCCESS, "Bienvenue %s sur l'application de gestion de stock" % request.user.username)

        if request.user.is_authenticated and request.user.is_superuser:
            stock_alert_sent = send_stock_alert_email(transfer_groups, request)
            if stock_alert_sent:
                messages.add_message(request, messages.WARNING, "L'alerte de stock a été envoyée aux différents chefs de projet.")
            else:
                messages.add_message(request, messages.INFO, "Aucune alerte de stock à signaler.")

            expired_articles_sent = send_expired_articles_email(request)
            if expired_articles_sent:
                messages.add_message(request, messages.WARNING, "L'email concernant les articles expirés a été envoyé.")
            else:
                messages.add_message(request, messages.INFO, "Aucun article expiré.")

    request.session['functions_executed'] = True
    
    return render(request, "index.html", {
        'transfer_groups': dict(transfer_groups),
        'all_transfers': all_transfers,
        'current_month_name':current_month_name,
        'transfers_count_input':transfers_count_input,
        'transfert_sortant':transfert_sortant,
        'total_transfer_week':total_transfer_week,
        'articles_expiring_this_month': articles_expiring_this_month,
        'data_json':data_json,

    
    })

def reset_password(request: HttpRequest):
    return render(request, "registration/password-reset.html")
