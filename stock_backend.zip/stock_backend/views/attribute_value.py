from django.http import HttpRequest, HttpResponseRedirect
from django.shortcuts import redirect
from django.urls import  reverse, reverse_lazy
from stock_backend.forms import AttributeValueForm
from stock_backend.models import Article, AttributeValue
from django.views.generic.edit import CreateView, DeleteView, UpdateView
from django.views.generic import ListView, DetailView
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.forms import modelformset_factory
from braces.views import FormMessagesMixin
from django.contrib import messages


@method_decorator(login_required, name='dispatch')
class AttributeValueListView(ListView):
    model = AttributeValue
    template_name = "pages/attributes_values/list.html"
    context_object_name = 'attributevalue_list'
    
    def get_queryset(self):
        queryset = AttributeValue.objects.all()
        return queryset

    """def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
             context = super().get_context_data(**kwargs)
        article = Article.objects.get(pk=self.kwargs['article'])
        context['article'] = article
        context['variants_list'] = AttributeValue.objects.filter(
            article=self.kwargs['article']
        )
        return context"""


@method_decorator(login_required, name='dispatch')
class AttributeValueCreateView(FormMessagesMixin, CreateView):
    model = AttributeValue
    form_class = AttributeValueForm
    template_name = "pages/attributes_values/create.html"
    success_url = reverse_lazy('attributevalue_list')
    form_invalid_message = "Oups, quelque chose s'est mal passé!"
    """
      Vue de création d'un transfer
    """
    model = AttributeValue
    form_class = AttributeValueForm
    template_name="pages/attributes_values/create.html"
    success_url=reverse_lazy('attributevalue_list')
    form_invalid_message="Oups,quelque chose s'est ma passé!"
    
    
    def get_form_valid_message(self):
        return u"{0} crée avec succés!".format(self.object.name)
    
    def post(self, request: HttpRequest, *args, **kwargs):
        # Look up the author we're interested in.
        print(f"Transfer Post : {request.POST}")
        # Actually record interest somehow here!
        form = AttributeValueForm(request.POST)
        if form.is_valid():
            form.save()
            messages.add_message(request,messages.SUCCESS,"Enregistrement effectuer avec succés  de  la value de l'attribut " )
            return HttpResponseRedirect(reverse('attributevalue_list'), {"form": form})
        else:
            print(f"Transfer form errors : {form.errors}")
            return HttpResponseRedirect(reverse('attributevalue_new'), {"form": form})
    
    
    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        context['form'] = AttributeValueForm
        context['method'] = "post"
        return context
    


@method_decorator(login_required, name='dispatch')
class AttributeValueUpdateView(FormMessagesMixin, UpdateView):
    model = AttributeValue
    form_class = AttributeValueForm
    template_name = "pages/attributes_values/create.html"
    success_url = reverse_lazy('attributevalue_list')
    form_invalid_message = "Oups, quelque chose s'est mal passé!"

    def get_form_valid_message(self):
        return u"modification effectuée avec succés!"

    # Recupère l'identifiant de l'objet caché dans le formulaire pour modifier le bon objet
    def get_object(self, **kwargs):
        print("AttributeValue Update data : {}".format(self.request.body))
        return AttributeValue.objects.get(pk=self.request.POST.get('pk'))

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        context['method'] = "put"
        context['form'] = AttributeValueForm
        return context


@method_decorator(login_required, name='dispatch')
class AttributeValueDeleteView(DeleteView):
    model = AttributeValue
    success_url = reverse_lazy('pages/attributes_values/list')


@method_decorator(login_required, name='dispatch')
class AttributeValueDetailView(DetailView):
    """
        Vue d'affichage d'un category
    """
    model = AttributeValue
    template_name = "pages/attributes_values/create.html"

    def get_context_data(self, **kwargs):
        """
            Surchage l'objet context
        """
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        obj = self.get_object()
        print(f"Detail request : {obj.pk}")
        context['form'] = AttributeValueForm(instance=obj)
        context['object'] = obj
        context['method'] = "put"
        return context
