from django.apps import AppConfig


class StockBackendConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'stock_backend'
    verbose_name = "Gestion de Stock"
    
    
    # def ready(self):
    #     import stock_backend.signals
    
    
    # def ready(self):
    #     import stock_backend.signals2
    
    
    
    
    
