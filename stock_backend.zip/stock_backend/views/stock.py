from django.http import HttpRequest, HttpResponseRedirect
from django.urls import reverse, reverse_lazy
from stock_backend.forms import StockForm
from stock_backend.models import Stock
from django.views.generic.edit import CreateView, DeleteView, UpdateView
from django.views.generic import ListView, DetailView
from django.contrib.auth.decorators import login_required,permission_required
from django.utils.decorators import method_decorator
from braces.views import FormMessagesMixin
from django.shortcuts import render
from django.contrib import messages 
@method_decorator(login_required, name='dispatch')
class StockListView(ListView):
    """
        vue d'affichage de la liste des projects
    """
    model = Stock
    context_object_name = 'stock_list'
    template_name = "pages/stock/list.html"
    
    def get_queryset(self):
        queryset = Stock.objects.all()
        return queryset


    
@method_decorator(login_required, name='dispatch')
class StockCreateView(FormMessagesMixin, CreateView):
    """
      Vue de création d'un project
    """
    model = Stock
    form_class = StockForm
    template_name = "pages/stock/create.html"
    success_url = reverse_lazy('stock_list')
    form_invalid_message = "Oups, quelque chose s'est mal passé!"

    def get_form_valid_message(self):
        return u"{0} crée avec succés!".format(self.object.title)

    def post(self, request: HttpRequest, *args, **kwargs):
        # Look up the author we're interested in.
        print(f"Stock Post : {request.POST}")
        # Actually record interest somehow here!
        form = StockForm(request.POST)
        if form.is_valid():
            form.save()
            messages.add_message(request,messages.SUCCESS,"Enregistrement effectuer avec succés  " )
            return HttpResponseRedirect(reverse('stock_list'))
        else:
            print(f"Stock form errors : {form.errors}")
            return HttpResponseRedirect(reverse('stock_new'), {"form": form})

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        context['form'] = StockForm
        context['method'] = "post"
        return context


@method_decorator(login_required, name='dispatch')
class StockUpdateView(FormMessagesMixin, UpdateView):
    """
      vue de mise à jour d'un project
    """
    model = Stock
    form_class = StockForm
    template_name = "pages/stock/create.html"
    success_url = reverse_lazy('stock_list')
    form_invalid_message = "Oups, quelque chose s'est mal passé!"

    def get_form_valid_message(self):
        return u" modification effectuée avec succés!"
    

    # Recupère l'identifiant de l'objet caché dans le formulaire pour modifier le bon objet
    def get_object(self, **kwargs):
        print("Stock Update data : {}".format(self.request.body))
        return Stock.objects.get(pk=self.request.POST.get('pk'))

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        context['method'] = "put"
        return context


@method_decorator(login_required, name='dispatch')
class StockDeleteView(DeleteView):
    model = Stock
    success_url = reverse_lazy('stock_list')


@method_decorator(login_required, name='dispatch')
class StockDetailView(DetailView):
    """
        Vue d'affichage d'un stock
    """
    model = Stock
    template_name = "pages/stock/create.html"

    def get_context_data(self, **kwargs):
        """
            Surchage l'objet context
        """
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        obj = self.get_object()
        print(f"Detail request : {obj.pk}")
        context['form'] = StockForm(instance=obj)
        context['object'] = obj
        context['method'] = "put"
        return context
