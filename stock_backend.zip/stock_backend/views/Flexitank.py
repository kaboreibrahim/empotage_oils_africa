from django.http import HttpRequest, HttpResponseRedirect
from django.urls import reverse, reverse_lazy
from stock_backend.forms import FlexitanksForm
from stock_backend.models import *
from django.views.generic.edit import CreateView, DeleteView, UpdateView
from django.views.generic import ListView, DetailView
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from braces.views import FormMessagesMixin
from django.shortcuts import render
from django.contrib import messages

@method_decorator(login_required, name='dispatch')
class FlexitankListView(ListView):
    """
        vue d'affichage de la liste des projects
    """
    model = Flexitanks
    context_object_name = 'Flexitank_list'
    template_name = "pages/Flexitank/list.html"

    def get_queryset(self):
        queryset = Flexitanks.objects.all()
        return queryset


@method_decorator(login_required, name='dispatch')
class FlextanksCreateView(FormMessagesMixin, CreateView):
    """
      Vue de création d'un project
    """
    model = Flexitanks
    form_class = FlexitanksForm
    template_name = "pages/Flexitank/create.html"
    success_url = reverse_lazy('Flexitank_list')
    form_invalid_message = "Oups, quelque chose s'est mal passé!"

    def get_form_valid_message(self):
        return u"{0} crée avec succés!".format(self.object.title)

    def post(self, request: HttpRequest, *args, **kwargs):
        # Look up the author we're interested in.
        print(f"Flexitanks Post : {request.POST}")
        # Actually record interest somehow here!
        form = FlexitanksForm(request.POST)
        if form.is_valid():
            form.save()
            messages.add_message(request,messages.SUCCESS,"Enregistrement effectuer avec succés  " )
            return HttpResponseRedirect(reverse('Flexitank_list'))
        else:
            print(f"Flexitanks form errors : {form.errors}")
            return HttpResponseRedirect(reverse('Flexitanks_create'), {"form": form})

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        context['form'] = FlexitanksForm
        context['method'] = "post"
        return context
    
