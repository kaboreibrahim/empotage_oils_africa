from django.http import HttpRequest, HttpResponseRedirect
from django.urls import reverse, reverse_lazy
from stock_backend.forms import firstform
from stock_backend.models import *
from django.views.generic.edit import CreateView, DeleteView, UpdateView
from django.views.generic import ListView, DetailView
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from braces.views import FormMessagesMixin
from django.shortcuts import render
from django.contrib import messages

@method_decorator(login_required, name='dispatch')
class FirstprojectListView(ListView):
    """
        vue d'affichage de la liste des projects
    """
    model = firstprojet
    context_object_name = 'firstprojet_list'
    template_name = "pages/firstprojet/list.html"

    def get_queryset(self):
        queryset = firstprojet.objects.all()
        return queryset
    



@method_decorator(login_required, name='dispatch')
class FirstprojetCreateView(FormMessagesMixin, CreateView):
    """
      Vue de création d'un project
    """
    model = firstprojet
    form_class = firstform
    template_name = "pages/firstprojet/create.html"
    success_url = reverse_lazy('firstprojet_list')
    form_invalid_message = "Oups, quelque chose s'est mal passé!"

    def get_form_valid_message(self):
        return u"{0} crée avec succés!".format(self.object.title)

    def post(self, request: HttpRequest, *args, **kwargs):
        # Look up the author we're interested in.
        print(f"HeatingPad Post : {request.POST}")
        # Actually record interest somehow here!
        form = firstform(request.POST)
        if form.is_valid():
            form.save()
            messages.add_message(request,messages.SUCCESS,"Enregistrement effectuer avec succés  " )
            return HttpResponseRedirect(reverse('firstprojet_list'))
        else:
            print(f"HeatingPad form errors : {form.errors}")
            return HttpResponseRedirect(reverse('firstprojet_create'), {"form": form})

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        context['form'] = firstform
        context['method'] = "post"
        return context
    
