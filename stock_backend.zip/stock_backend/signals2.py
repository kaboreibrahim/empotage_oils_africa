

from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import Rapport,firstprojet

@receiver(post_save, sender=Rapport)
def change_projet_statut(sender, instance, created, **kwargs):
    if created:  # Vérifiez si un nouveau rapport a été créé
        # Appeler la méthode pour terminer le projet

                instance.Project.terminer_projet()
        # # Appliquer sortir_flexitank à chaque Flexitank associé
        # for flexitank in instance.flexitanks.all():
        #     flexitank.sortir_flexitank()
            

        # # Appliquer sortir_HeatingPad à chaque HeatingPad associé
        # for heating_pad in instance.heating_pads.all():
        #     heating_pad.sortir_HeatingPad()
