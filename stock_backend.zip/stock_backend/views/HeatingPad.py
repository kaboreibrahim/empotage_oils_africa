from django.http import HttpRequest, HttpResponseRedirect
from django.urls import reverse, reverse_lazy
from stock_backend.forms import HeatingPadForm
from stock_backend.models import *
from django.views.generic.edit import CreateView, DeleteView, UpdateView
from django.views.generic import ListView, DetailView
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from braces.views import FormMessagesMixin
from django.shortcuts import render
from django.contrib import messages

@method_decorator(login_required, name='dispatch')
class HeatingPadListView(ListView):
    """
        vue d'affichage de la liste des projects
    """
    model = HeatingPad
    context_object_name = 'HeatingPad_list'
    template_name = "pages/HeatingPad/list.html"

    def get_queryset(self):
        queryset = HeatingPad.objects.all()
        return queryset

@method_decorator(login_required, name='dispatch')
class HeatingPadCreateView(FormMessagesMixin, CreateView):
    """
      Vue de création d'un project
    """
    model = HeatingPad
    form_class = HeatingPadForm
    template_name = "pages/HeatingPad/create.html"
    success_url = reverse_lazy('HeatingPad_list')
    form_invalid_message = "Oups, quelque chose s'est mal passé!"

    def get_form_valid_message(self):
        return u"{0} crée avec succés!".format(self.object.title)

    def post(self, request: HttpRequest, *args, **kwargs):
        # Look up the author we're interested in.
        print(f"HeatingPad Post : {request.POST}")
        # Actually record interest somehow here!
        form = HeatingPadForm(request.POST)
        if form.is_valid():
            form.save()
            messages.add_message(request,messages.SUCCESS,"Enregistrement effectuer avec succés  " )
            return HttpResponseRedirect(reverse('HeatingPad_list'))
        else:
            print(f"HeatingPad form errors : {form.errors}")
            return HttpResponseRedirect(reverse('HeatingPad_create'), {"form": form})

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        context['form'] = HeatingPadForm
        context['method'] = "post"
        return context
    
