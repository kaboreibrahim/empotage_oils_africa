from django.contrib import admin
# https://django-safedelete.readthedocs.io/en/latest/
from simple_history.admin import SimpleHistoryAdmin
# https://django-import-export.readthedocs.io/en/latest/
from import_export.admin import ImportExportModelAdmin
from import_export import resources
from stock_backend.forms import ArticleForm, CategoryForm, AttributeForm, AttributeValueForm, ArticleVariantForm,TransferForm

from stock_backend.models import Category, Image, Article, Transfer, ArticleSerialLot, Project, \
    Stock, UserProfile, Attribute, AttributeValue, ArticleVariant,Fournisseurs ,Flexitanks,HeatingPad,firstprojet,Rapport


# Position

class TransferResource(resources.Resource):
    """model resource for transfer"""
    
    class Meta:
        model=Transfer
        
class TransferAdmin(SimpleHistoryAdmin, ImportExportModelAdmin):
    """A model admin for Category."""

    form = TransferForm
    resource_class = TransferResource
    



class AttributeValueResource(resources.ModelResource):
    """Model Resource for Article."""

    class Meta:
        model = AttributeValue
        
class CategoryResource(resources.ModelResource):
    """Model Resource for Article."""

    class Meta:
        model = Category


class AttributeResource(resources.ModelResource):
    """Model Resource for Attribute."""

    class Meta:
        model = Attribute


class ArticleResource(resources.ModelResource):
    """Model Resource for Category."""

    class Meta:
        model = Article


class ArticleVariantResource(resources.ModelResource):
    """Model Resource for Article variant."""

    class Meta:
        model = ArticleVariant


class AttributeValueInline(admin.TabularInline):
    model = ArticleVariant.attributes.through
    extra = 0


class ArticleAdmin(SimpleHistoryAdmin, ImportExportModelAdmin):
    """A model admin for Article."""

    form = ArticleForm
    resource_class = ArticleResource


class ArticleVariantAdmin(SimpleHistoryAdmin, ImportExportModelAdmin):
    """A model admin for Article."""

    form = ArticleVariantForm
    resource_class = ArticleVariantResource
    inlines = [
        AttributeValueInline,
    ]


class AttributeValueAdmin(SimpleHistoryAdmin, ImportExportModelAdmin):
    """A model admin for Article."""

    form = AttributeValueForm
    resource_class = AttributeValueResource


class CategoryAdmin(SimpleHistoryAdmin, ImportExportModelAdmin):
    """A model admin for Category."""

    form = CategoryForm
    resource_class = CategoryResource


class AttributeAdmin(SimpleHistoryAdmin, ImportExportModelAdmin):
    """A model admin for Category."""

    form = AttributeForm
    resource_class = AttributeResource



# ImplementingChain


# Register your models here.
admin.site.register(Project)
admin.site.register(Stock)
admin.site.register(Category, CategoryAdmin)
admin.site.register(Attribute, AttributeAdmin)
admin.site.register(Article, ArticleAdmin)
admin.site.register(ArticleVariant, ArticleVariantAdmin)
admin.site.register(AttributeValue, AttributeValueAdmin)
admin.site.register(Transfer,TransferAdmin)
admin.site.register(ArticleSerialLot)
admin.site.register(Image)
admin.site.register(UserProfile)
admin.site.register(Fournisseurs)
admin.site.register(Flexitanks)
admin.site.register(HeatingPad)
admin.site.register(firstprojet)
admin.site.register(Rapport)

