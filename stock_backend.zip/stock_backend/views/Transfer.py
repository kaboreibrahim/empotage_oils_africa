from datetime import datetime, timedelta, timezone
import json

from django.db.models import Sum
import requests


from django.http import HttpRequest, HttpResponseRedirect
from django.urls import reverse, reverse_lazy
from django.core.mail import send_mail

from stock_backend.forms import TransferForm
from stock_backend.models import   Transfer,Stock
from django.views.generic.edit import CreateView, DeleteView, UpdateView
from django.views.generic import ListView, DetailView
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from braces.views import FormMessagesMixin
from django.contrib import messages

# Vue pour afficher le stock et effectuer des transferts




from datetime import datetime

@method_decorator(login_required, name='dispatch')
class TransferListView(ListView):
    model = Transfer
    context_object_name = 'Transfer_lists'
    template_name = "pages/transfer/historique.html"

    def get_queryset(self):

        # Récupérer les paramètres de date de début et de fin à partir de la requête
        start_date = self.request.GET.get('start_date')
        end_date = self.request.GET.get('end_date')

        # Convertir les chaînes de caractères en objets datetime
        if start_date and end_date:
            start_date = datetime.strptime(start_date, '%Y-%m-%d')
            end_date = datetime.strptime(end_date, '%Y-%m-%d')

        queryset = Transfer.objects.filter(origin_of_transfer__label='FOURNISSEURS')

        # Filtrer les transferts en fonction des dates de début et de fin
        if start_date and end_date:
            queryset = queryset.filter(created_at__range=(start_date, end_date + timedelta(days=1)))

        # Trier les transferts par date de création décroissante
        queryset = queryset.order_by('-created_at')
        return queryset

    
@method_decorator(login_required, name='dispatch')
class TransferCreateView(FormMessagesMixin, CreateView):
    """
      Vue de création d'un transfer
    """
    model = Transfer
    form_class = TransferForm
    template_name="pages/transfer/create.html"
    success_url=reverse_lazy('Transfer_new')
    form_invalid_message = "Oups, quelque chose s'est mal passé!"
    
    def get_form_valid_message(self):
        
        return u"{0} crée avec succés!".format(self.object.name)
    
    def get_form_error_message(self):
        return u"Une erreur s'est produite lors de la création de {0}.".format(self.object.name)
    
    def post(self, request: HttpRequest, *args, **kwargs):

        # Look up the author we're interested in.
        print(f"Transfer Post : {request.POST}")
        # Actually record interest somehow here!
        form = TransferForm(request.POST)
        if form.is_valid():
            
            
            serial_lot_of_item = form.cleaned_data['serial_lot_of_item']
            serial_lot_of_item_id = serial_lot_of_item.id
            
    
            origin_of_transfer = form.cleaned_data['origin_of_transfer']
            origin_of_transfer_id = origin_of_transfer.id
                
            destination_of_transfer = form.cleaned_data['destination_of_transfer']
            destination_of_transfer_id = destination_of_transfer.id
            
            quantity=form.cleaned_data['quantity']
            print(quantity)
                       
            provider=Stock.objects.filter(label="FOURNISSEURS").first()
            
            if origin_of_transfer == provider:
                
                transfers_fournisseur = Transfer.objects.filter(
                    origin_of_transfer=provider.id,
                    destination_of_transfer=destination_of_transfer.id,
                    serial_lot_of_item=serial_lot_of_item.id)
                print( f'fournisseur {transfers_fournisseur}')
                
                total_quantity_transfers_fournisseur = transfers_fournisseur.aggregate(
                    total_quantity_transfers_fournisseur=Sum('quantity'))['total_quantity_transfers_fournisseur'] or 0
                
                transfers_outS = Transfer.objects.filter(
                    serial_lot_of_item=serial_lot_of_item_id,
                    origin_of_transfer=destination_of_transfer_id,     
                )
            
                outs_somme = transfers_outS.aggregate(outs_somme=Sum('quantity'))['outs_somme'] or 0
                total=(total_quantity_transfers_fournisseur - outs_somme)
                TOTAL=total+quantity 
                               
                messages.add_message(request,messages.SUCCESS,f" La stock de ({destination_of_transfer}) pour l'article {serial_lot_of_item} a reçu une quantité de : {quantity} . À présent, le stock total s'élève à :{TOTAL}" )
            form.save()
            
            return HttpResponseRedirect(reverse('Transfer_lists'), {"form": form})
        else:
           
            serial_lot_of_item = form.cleaned_data['serial_lot_of_item']
            
            form=TransferForm()
            date_actuelle = datetime.now().replace(tzinfo=timezone.utc)
            Date_expire = serial_lot_of_item.expiry_date
            
            if Date_expire is not None:
                date_actuelle = date_actuelle.replace(minute=0, second=0, microsecond=0)
                Date_expire = Date_expire.replace(minute=0, second=0, microsecond=0)

                # Calcul de la différence entre les deux dates
                difference = Date_expire - date_actuelle

                if difference.days<=0:
                    messages.add_message(request,messages.WARNING,f"  l'article {serial_lot_of_item}   a expiré  depuis plus de : {-difference} " )  
                else:
                    messages.add_message(request,messages.ERROR,f" La quantité actuelle disponible pour le projet pour l'article est epuise " )

        print(f"Transfer form errors : {form.errors}")
            
        return HttpResponseRedirect(reverse('Transfer_new'),{"form": form})

    
    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        context['form'] = TransferForm
        context['method'] = "post"
        return context
   


@method_decorator(login_required, name='dispatch')
class TransferUpdateView(FormMessagesMixin, UpdateView):
    """
      vue de mise à jour d'un transfer
    """
    model = Transfer
    form_class = TransferForm
    template_name = "pages/transfer/create.html"
    success_url = reverse_lazy('Transfer_lists')
    
   
    def get_form_valid_message(self):
        return u" Modification effectueé avec succès!"

    # Recupère l'identifiant de l'objet caché dans le formulaire pour modifier le bon objet
    def get_object(self, **kwargs):
        print("Transfer Update data : {}".format(self.request.body))
        return Transfer.objects.get(pk=self.request.POST.get('pk'))

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        context['method'] = "put"
        return context

@method_decorator(login_required, name='dispatch')
class TransferDeleteView(DeleteView):
    model = Transfer
    template_name="pages/transfer/delete.html"
    success_url = reverse_lazy('ma_vue')


@method_decorator(login_required, name='dispatch')
class TransferDetailView(DetailView):
    """
        Vue d'affichage d'un stock
    """
    model = Transfer
    template_name = "pages/transfer/create.html"

    def get_context_data(self, **kwargs):
        """
            Surchage l'objet context
        """
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        obj = self.get_object()
        print(f"Detail request : {obj.pk}")
        context['form'] = TransferForm(instance=obj)
        context['object'] = obj
        context['method'] = "put"
        return context
   
    
    