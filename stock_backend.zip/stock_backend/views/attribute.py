from django.http import HttpRequest, HttpResponseRedirect
from django.urls import reverse, reverse_lazy
from stock_backend.forms import AttributeForm
from stock_backend.models import Attribute
from django.views.generic.edit import CreateView, DeleteView, UpdateView
from django.views.generic import ListView, DetailView
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from braces.views import FormMessagesMixin
from django.contrib import messages



@method_decorator(login_required, name='dispatch')
class AttributeListView(ListView):
    """
        vue d'affichage de la liste des articles
    """
    model = Attribute
    context_object_name = 'attribute_list'
    template_name = "pages/attributes/list.html"

    def get_queryset(self):
        queryset = Attribute.objects.all()
        return queryset


@method_decorator(login_required, name='dispatch')
class AttributeCreateView(FormMessagesMixin, CreateView):
    """
      Vue de création d'un article
    """
    model = Attribute
    form_class = AttributeForm
    template_name = "pages/attributes/create.html"
    success_url = reverse_lazy('attribute-list')
    form_invalid_message = "Oups, quelque chose s'est mal passé!"

    def get_form_valid_message(self):
        return u"{0} crée avec succés!".format(self.object.label)

    def post(self, request: HttpRequest, *args, **kwargs):
        # Look up the author we're interested in.
        print(f"Article Post : {request.POST}")
        # Actually record interest somehow here!
        form = AttributeForm(request.POST)
        if form.is_valid():
            form.save()
            messages.add_message(request,messages.SUCCESS," ENREGISTREMENT DE LA L'ATTRIBUT ")
            return HttpResponseRedirect(reverse("attribute-list"),{"form": form})
        else:
            print(f"Attribute form errors : {form.errors}")
            messages.add_message(request,messages.ERROR," L'ATTRIBUT EST DEJA ENREGISTRER ")
            return HttpResponseRedirect(reverse('attribute-new'), {"form": form})

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        context['form'] = AttributeForm
        context['method'] = "post"
        return context


@method_decorator(login_required, name='dispatch')
class AttributeUpdateView(FormMessagesMixin, UpdateView):
    """
      vue de mise à jour d'un article
    """
    model = Attribute
    form_class = AttributeForm
    template_name = "pages/attributes/create.html"
    success_url = reverse_lazy('attribute-list')
    form_invalid_message = "Oups, quelque chose s'est mal passé!"

    def get_form_valid_message(self):
        return u"modification effectuée avec succès!"

    # Recupère l'identifiant de l'objet caché dans le formulaire pour modifier le bon objet
    def get_object(self, **kwargs):
        print("Project Update data : {}".format(self.request.body))
        return Attribute.objects.get(pk=self.request.POST.get('pk'))

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        context['method'] = "put"
        return context


@method_decorator(login_required, name='dispatch')
class AttributeDeleteView(DeleteView):
    model = Attribute
    success_url = reverse_lazy('attribute-list')


@method_decorator(login_required, name='dispatch')
class AttributeDetailView(DetailView):
    """
        Vue d'affichage d'un article
    """
    model = Attribute
    template_name = "pages/attributes/create.html"

    def get_context_data(self, **kwargs):
        """
            Surchage l'objet context
        """
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        obj = self.get_object()
        print(f"Detail request : {obj.pk}")
        context['form'] = AttributeForm(instance=obj)
        context['object'] = obj
        context['method'] = "put"
        return context
