from datetime import datetime, timezone
import json

from django.db.models import Sum


from django.http import HttpRequest, HttpResponseRedirect
from django.urls import reverse, reverse_lazy
from django.core.mail import send_mail
import requests

from stock_backend.forms import TransferFormout,listForm,UserProfile
from stock_backend.models import  Transfer,Stock
from django.views.generic.edit import CreateView, DeleteView, UpdateView
from django.views.generic import ListView, DetailView
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from braces.views import FormMessagesMixin
from django.contrib import messages
from django.shortcuts import render,redirect


"""
def view_stock(request):
    form_submitted = False

    if request.method == 'POST':
         # Initialiser le formulaire avec les données du POST
        form = listForm(request.POST, initial={'user': request.user})
        if form.is_valid():
            # Récupérer les IDs sélectionnés
            serial_lot_of_item = form.cleaned_data['serial_lot_of_item']
            serial_lot_of_item_id = serial_lot_of_item.id
            
            origin_of_transfer = form.cleaned_data['origin_of_transfer']
            origin_of_transfer_id = origin_of_transfer.id
            
            destination_of_transfer = form.cleaned_data['destination_of_transfer']
            destination_of_transfer_id = destination_of_transfer.id
                        
            date_actuelle = datetime.now().replace(tzinfo=timezone.utc)
            Date_expire = serial_lot_of_item.expiry_date
            
            # Vérification si la date d'expiration est présente
            if Date_expire is not None:
                date_actuelle = date_actuelle.replace(minute=0, second=0, microsecond=0)
                Date_expire = Date_expire.replace(minute=0, second=0, microsecond=0)

                # Calcul de la différence entre les deux dates
                difference = Date_expire - date_actuelle
                

                # Formatage des dates
                date_actuelle_format = date_actuelle.strftime('%Y-%m-%d-%H:%M')
                Date_expire_format = Date_expire.strftime('%Y-%m-%d%H:%M')

                # Affichage de la différence
                print(f"Date actuelle : {date_actuelle_format}")
                print(f"Date d'expiration : {Date_expire_format}")
                print(f"Date d'expiration : {difference}")
                if difference.days<=0:
                    messages.add_message(request,messages.WARNING,f"  l'article {serial_lot_of_item}   a expiré  depuis plus de : {-difference} " )
                    
                else:
                    messages.add_message(request,messages.WARNING,f" La date d'expiration pour l'article {serial_lot_of_item}   est dans :{difference}" )

            else:
                messages.add_message(request,messages.WARNING,f" La date d'expiration n'est pas spécifiée pour l'article {serial_lot_of_item} " )
                
                print("La date d'expiration n'est pas spécifiée (None), aucune opération n'a été effectuée.")

            
            
            start_date=form.cleaned_data['date_debut']
            print(f'date de debut:{start_date}')

            end_date=form.cleaned_data['date_fin']
            print(f'date de fin :{end_date}')
            
            print(f'ID de article :{serial_lot_of_item_id}')
            print(f' ID de origine :{origin_of_transfer_id}')
            print(f' ID de destination :{destination_of_transfer_id}')

            provider = Stock.objects.filter(label="FOURNISSEURS").first()

            start_date = datetime.combine(start_date, datetime.min.time())
            end_date = datetime.combine(end_date, datetime.max.time())

            transfers_inp = Transfer.objects.filter(
                serial_lot_of_item=serial_lot_of_item_id,
                origin_of_transfer=provider.id,
                destination_of_transfer=destination_of_transfer_id,
                #created_at__range=(start_date, end_date) 
            )
            print(f'transfert entrant : {transfers_inp}')

            transfers_out = Transfer.objects.filter(
                serial_lot_of_item=serial_lot_of_item_id,
                origin_of_transfer=destination_of_transfer_id,
              
                #created_at__range=(start_date, end_date) 
            )
            print(f'transfert sortant :{transfers_out}')
          
            total_quantity_out = transfers_out.aggregate(total_quantity_out=Sum('quantity'))['total_quantity_out'] or 0
            total_quantity_inp = transfers_inp.aggregate(total_quantity_inp=Sum('quantity'))['total_quantity_inp'] or 0

            total_quantity_rest = total_quantity_inp - total_quantity_out
            print(f' la quantite de  l\'article restante est de : {total_quantity_rest} ')
             # diagramme circulaire
            chart_data = [
                {"label": "Quantités de  sortie", "value": total_quantity_out},
                {"label": "Quantités d'entrées ", "value": total_quantity_inp},
                
                {"label": "Quantités Restante", "value": total_quantity_rest},
            ]
            chart_data_json = json.dumps(chart_data)
             # diagramme circulaire en pourcentage
            try :
                total_quantity_out_percentage = int((total_quantity_out / (total_quantity_out + total_quantity_rest)) * 100)
            except ZeroDivisionError:
                total_quantity_out_percentage = 0
            try:
                total_quantity_rest_percentage = int((total_quantity_rest / (total_quantity_out + total_quantity_rest)) * 100)
            except ZeroDivisionError:
                total_quantity_rest_percentage = 0
                

            if total_quantity_rest<=5 :
                messages.add_message(request,messages.ERROR,f" la quantité restante pour le projet  {destination_of_transfer} pour l'article {serial_lot_of_item} est  :{total_quantity_rest} , Songer a  procéder au réapprovisionnement du  stock" )
                
            else:
                messages.add_message(request,messages.SUCCESS,f" la quantité restante pour le projet  {destination_of_transfer} pour l'article {serial_lot_of_item}  est  :{total_quantity_rest}" )
                
                        
            form_submitted = True
           
            
            return render(request, 'pages/transfer/view.html',  {
                'form': form,
                'form_submitted': form_submitted,
                'transfers_out': transfers_out,
                'transfers_inp': transfers_inp,
                'total_quantity_out': total_quantity_out,
                'total_quantity_inp': total_quantity_inp,
                'total_quantity_rest': total_quantity_rest,
                'serial_lot_of_item':serial_lot_of_item,
                'destination_of_transfer':destination_of_transfer,
                'chart_data_json': chart_data_json,
                'percentage_values': {
                        'total_quantity_out_percentage':total_quantity_out_percentage ,
                        'total_quantity_rest_percentage':total_quantity_rest_percentage,
                },
                'labels': {
                            'total_quantity_inp_label': 'pourcentage entre ',
                            'total_quantity_out_label': 'pourcentage de sortie',
                            'total_quantity_rest_label': 'quantité restante',
                        },
            })
            
        form_submitted = True
       
    else:
        form = listForm(initial={'user': request.user})
    return render(request, 'pages/transfer/view.html', {'form': form , 'form_submitted': form_submitted})
"""
def view_stock(request):
    form_submitted = False

    if request.method == 'POST':
        form = listForm(request.POST, initial={'user': request.user})
        if form.is_valid():
            serial_lot_of_item = form.cleaned_data['serial_lot_of_item']
            origin_of_transfer = form.cleaned_data['origin_of_transfer']
            destination_of_transfer = form.cleaned_data['destination_of_transfer']
            date_debut = form.cleaned_data['date_debut']
            date_fin = form.cleaned_data['date_fin']

            date_actuelle = datetime.now(timezone.utc).replace(minute=0, second=0, microsecond=0)
            Date_expire = serial_lot_of_item.expiry_date.replace(minute=0, second=0, microsecond=0) if serial_lot_of_item.expiry_date else None

            if Date_expire:
                difference = Date_expire - date_actuelle
                if difference.days <= 0:
                    messages.warning(request, f"l'article {serial_lot_of_item} a expiré depuis plus de : {-difference}")
                else:
                    messages.warning(request, f"La date d'expiration pour l'article {serial_lot_of_item} est dans :{difference}")
            else:
                messages.warning(request, f"La date d'expiration n'est pas spécifiée pour l'article {serial_lot_of_item}")

            provider = Stock.objects.filter(label="FOURNISSEURS").first()

            # Filtrer par plage de dates si spécifiée
            transfers_inp = Transfer.objects.filter(
                serial_lot_of_item=serial_lot_of_item.id,
                origin_of_transfer=provider.id,
                destination_of_transfer=destination_of_transfer.id,
            )
            transfers_out = Transfer.objects.filter(
                serial_lot_of_item=serial_lot_of_item.id,
                origin_of_transfer=destination_of_transfer.id,
            )

            if date_debut:
                transfers_inp = transfers_inp.filter(created_at__gte=date_debut)
                transfers_out = transfers_out.filter(created_at__gte=date_debut)
            if date_fin:
                transfers_inp = transfers_inp.filter(created_at__lte=date_fin)
                transfers_out = transfers_out.filter(created_at__lte=date_fin)
            
            total_quantity_out = transfers_out.aggregate(total_quantity_out=Sum('quantity'))['total_quantity_out'] or 0
            total_quantity_inp = transfers_inp.aggregate(total_quantity_inp=Sum('quantity'))['total_quantity_inp'] or 0
            total_quantity_rest = total_quantity_inp - total_quantity_out
           
            chart_data = [
                {"label": "Quantités de sortie", "value": total_quantity_out},
                {"label": "Quantités d'entrées", "value": total_quantity_inp},
                {"label": "Quantités Restante", "value": total_quantity_rest},
            ]
            chart_data_json = json.dumps(chart_data)

            total_quantity_out_percentage = int((total_quantity_out / (total_quantity_out + total_quantity_rest)) * 100) if total_quantity_out + total_quantity_rest > 0 else 0
            total_quantity_rest_percentage = int((total_quantity_rest / (total_quantity_out + total_quantity_rest)) * 100) if total_quantity_out + total_quantity_rest > 0 else 0

            if total_quantity_rest <= 5:
                messages.error(request, f"la quantité restante pour le projet {destination_of_transfer} pour l'article {serial_lot_of_item} est :{total_quantity_rest}, Songer à procéder au réapprovisionnement du stock")
            else:
                messages.success(request, f"la quantité restante pour le projet {destination_of_transfer} pour l'article {serial_lot_of_item} est :{total_quantity_rest}")

            form_submitted = True

            return render(request, 'pages/transfer/view.html', {
                'form': form,
                'form_submitted': form_submitted,
                'transfers_out': transfers_out,
                'transfers_inp': transfers_inp,
                'total_quantity_out': total_quantity_out,
                'total_quantity_inp': total_quantity_inp,
                'total_quantity_rest': total_quantity_rest,
                'serial_lot_of_item': serial_lot_of_item,
                'destination_of_transfer': destination_of_transfer,
                'chart_data_json': chart_data_json,
                'percentage_values': {
                    'total_quantity_out_percentage': total_quantity_out_percentage,
                    'total_quantity_rest_percentage': total_quantity_rest_percentage,
                },
                'labels': {
                    'total_quantity_inp_label': 'pourcentage entre',
                    'total_quantity_out_label': 'pourcentage de sortie',
                    'total_quantity_rest_label': 'quantité restante',
                },
            })

        form_submitted = True

    else:
        form = listForm(initial={'user': request.user})

    return render(request, 'pages/transfer/view.html', {'form': form, 'form_submitted': form_submitted})
from datetime import timedelta

from datetime import datetime, timedelta
def no_data_page(request):
    return render(request, 'no_data.html')

class TransferListViewout(ListView):
    model = Transfer
    context_object_name = 'Transfer_lists_out'
    template_name = "pages/transfer/historique_out_flexitank.html"

    def get_queryset(self):
        # Récupérer l'utilisateur connecté
        user = self.request.user

        user_profile = UserProfile.objects.get(user=user)

        project = user_profile.project
        print(project)

        # Afficher les stocks liés au projet
        stocks = Stock.objects.filter(project=project)
        print("Stocks liés au projet :")
        for stock in stocks:
            print(stock.label)

        # Récupérer les paramètres de date de début et de fin à partir de la requête
        start_date = self.request.GET.get('start_date')
        end_date = self.request.GET.get('end_date')

        # Convertir les chaînes de caractères en objets datetime
        if start_date and end_date:
            start_date = datetime.strptime(start_date, '%Y-%m-%d')
            end_date = datetime.strptime(end_date, '%Y-%m-%d')

        # Si l'utilisateur est super utilisateur, afficher tous les transferts sauf ceux dont l'origine est "FOURNISSEURS"
        if user.is_superuser:
            queryset = Transfer.objects.exclude(origin_of_transfer__label='FOURNISSEURS')
        else:
            # Sinon, filtrer les transferts en fonction du projet de l'utilisateur connecté et exclure ceux dont l'origine est "FOURNISSEURS"
            queryset = Transfer.objects.filter(origin_of_transfer__project=project).exclude(origin_of_transfer__label='FOURNISSEURS')

        # Filtrer les transferts en fonction des dates de début et de fin
        if start_date and end_date:
            queryset = queryset.filter(created_at__range=(start_date, end_date + timedelta(days=1)))

        return queryset.order_by('-created_at')

    

@method_decorator(login_required, name='dispatch')
class TransferCreateViewout(FormMessagesMixin, CreateView):
    """
      Vue de création d'un transfer
    """
    model = Transfer
    form_class = TransferFormout
    template_name="pages/transfer/create_out.html"
    success_url=reverse_lazy('Transfer_lists_out')
    form_invalid_message = "Oups, quelque chose s'est mal passé!"
    
    def get_form_valid_message(self):
        
        return u"{0} crée avec succés!".format(self.object.name)
    
    def get_form_error_message(self):
        return u"Une erreur s'est produite lors de la création de {0}.".format(self.object.name)
    
    def post(self, request: HttpRequest, *args, **kwargs):
        
         # Look up the author we're interested in.
        print(f"Transfer Post : {request.POST}")
        # Actually record interest somehow here!
        form = TransferFormout(request.POST )
        
        if form.is_valid():
            
            serial_lot_of_item = form.cleaned_data['serial_lot_of_item']
            serial_lot_of_item_id = serial_lot_of_item.id
            
    
            origin_of_transfer = form.cleaned_data['origin_of_transfer']
            origin_of_transfer_id = origin_of_transfer.id
                
            destination_of_transfer = form.cleaned_data['destination_of_transfer']
            destination_of_transfer_id = destination_of_transfer.id
            
            quantity=form.cleaned_data['quantity']
            print(quantity)
                       
            provider=Stock.objects.filter(label="FOURNISSEURS").first()
            
            if origin_of_transfer == provider:
                
                transfers_fournisseur = Transfer.objects.filter(
                    origin_of_transfer=provider.id,
                    destination_of_transfer=destination_of_transfer.id,
                    serial_lot_of_item=serial_lot_of_item.id)
                print( f'fournisseur {transfers_fournisseur}')
                
                total_quantity_transfers_fournisseur = transfers_fournisseur.aggregate(
                    total_quantity_transfers_fournisseur=Sum('quantity'))['total_quantity_transfers_fournisseur'] or 0
                
                transfers_outS = Transfer.objects.filter(
                    serial_lot_of_item=serial_lot_of_item_id,
                    origin_of_transfer=destination_of_transfer_id,     
                )
            
                outs_somme = transfers_outS.aggregate(outs_somme=Sum('quantity'))['outs_somme'] or 0
                total=(total_quantity_transfers_fournisseur - outs_somme)
                TOTAL=total+quantity 
                               
                messages.add_message(request,messages.SUCCESS,f" La stock de ({destination_of_transfer}) pour l'article {serial_lot_of_item} a reçu une quantité de : {quantity} . À présent, le stock total s'élève à :{TOTAL}" )
            else:
              
                print(f'ID de article :{serial_lot_of_item}')
                print(f' ID de origine :{origin_of_transfer}')
                print(f' ID de destination :{destination_of_transfer}')
                print(f' valeur quantity :{quantity}')
                
                transfers_inp = Transfer.objects.filter(
                serial_lot_of_item=serial_lot_of_item_id,
                origin_of_transfer=provider.id,
                destination_of_transfer=origin_of_transfer_id,
                
                ).all()
                
                print(f'transfert entrant : {transfers_inp}')

                transfers_out = Transfer.objects.filter(
                    serial_lot_of_item=serial_lot_of_item_id,
                    origin_of_transfer=origin_of_transfer_id,
                )
                print(f'transfert sortant :{transfers_out}')
                

                total_quantity_out = transfers_out.aggregate(total_quantity_out=Sum('quantity'))['total_quantity_out'] or 0
                total_quantity_inp = transfers_inp.aggregate(total_quantity_inp=Sum('quantity'))['total_quantity_inp'] or 0

                total_quantity_rest = total_quantity_inp - total_quantity_out
                print(f"La somme des entrées form : {total_quantity_inp}")
                print(f"La somme des sorties formu : {total_quantity_out}")

                print(f' total quantite restant:{total_quantity_rest}')
                Total=total_quantity_rest-quantity
                print()
                try:
                    requests.get('https://www.google.com', timeout=5)
                except requests.ConnectionError:
                        if Total <= 5 :
                            messages.add_message(request, messages.ERROR, "Problème de connexion. Impossible d'envoyer le e-mails rappel de stock. Veuillez réessayer plus tard.")
                            messages.add_message(request,messages.ERROR,f" La quantité actuelle disponible pour le projet {origin_of_transfer} concernant l'article {serial_lot_of_item} s'élève à : {Total}"  )
                        else:
                            messages.add_message(request,messages.SUCCESS,f" La quantité actuelle disponible pour le projet {origin_of_transfer} concernant l'article {serial_lot_of_item} s'élève à : {Total}"  )

                        form.save()
                        return HttpResponseRedirect(reverse('Transfer_lists_out'), {"form": form})
                       
                if Total <= 5 :
                        
                   
                    
                    messages.add_message(request,messages.INFO,f"VOUS AVEZ RECU UN MAIL...(D'alert de seuil d'approvisionnement )" )
                    subject = f"Alerte de stock de réapprovisionnement"
                    message=f"La disponibilité actuelle d'articles : {serial_lot_of_item} pour le projet : {origin_of_transfer} est de  :{Total}. Il est recommandé de planifier un réapprovisionnement du stock pour éviter toute interruption."
                    send_mail(
                            subject,
                            message,
                            'ibrahimkabore025@gmail.com',  # Replace with your Gmail address or sender's email address
                            ['ibrahimkabore025@gmail.com'],  # Replace with the recipient's email address
                            fail_silently=False,    
                    )
                    messages.add_message(request,messages.ERROR,f" La quantité actuelle disponible pour le projet {origin_of_transfer} concernant l'article {serial_lot_of_item} s'élève à : {Total}"  )
                else:
                    messages.add_message(request,messages.INFO,f"La quantité actuelle disponible pour le projet {origin_of_transfer} concernant l'article {serial_lot_of_item} s'élève à : {Total}"  )
            form.save()
            #messages.add_message(request, messages.SUCCESS, "Enregistrement effectué avec succès du transfert")
            
            return HttpResponseRedirect(reverse('Transfer_lists_out'), {"form": form})
        
        else:
            serial_lot_of_item = form.cleaned_data['serial_lot_of_item']
            
            form = TransferFormout()
            date_actuelle = datetime.now().replace(tzinfo=timezone.utc)
            Date_expire = serial_lot_of_item.expiry_date
    
            if Date_expire is not None:
                date_actuelle = date_actuelle.replace(minute=0, second=0, microsecond=0)
                Date_expire = Date_expire.replace(minute=0, second=0, microsecond=0)

                # Calcul de la différence entre les deux dates
                difference = Date_expire - date_actuelle

                if difference.days<=0:
                    messages.add_message(request,messages.WARNING,f"  l'article {serial_lot_of_item}   a expiré  depuis plus de : {-difference} " )  
            else:
                messages.add_message(request, messages.ERROR, f" La quantité demandée est supérieure à la quantité disponible.")

        print(f"Transfer form errors : {form.errors}")
            
        return HttpResponseRedirect(reverse('Transfer_new_out'),{"form": form})
    
    def get_context_data(self, **kwargs):
        # Si l'utilisateur est un superutilisateur, exécutez la première fonction
        if self.request.user.is_superuser:
            return self.get_context_data_superuser(**kwargs)
        # Sinon, exécutez la deuxième fonction
        else:
            return self.get_context_data_user(**kwargs)

    def get_context_data_superuser(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        context['form'] = TransferFormout
        context['method'] = "post"
        return context

    def get_context_data_user(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        form = TransferFormout()  # Crée une instance du formulaire de transfert

        project_choice = [("","-----------------------")]  # Initialise une liste de choix de projet avec un choix par défaut
        project_choices = [("","-----------------------")]  # Initialise une liste de choix de projet avec un choix par défaut

        user = self.request.user  # Récupère l'utilisateur actuel à partir de la requête
        user_profile = UserProfile.objects.get(user=user)  # Récupère le profil utilisateur associé à l'utilisateur actuel
        project = user_profile.project  # Récupère le projet associé au profil utilisateur

        # Parcourt tous les stocks associés au projet et les ajoute à la liste de choix de projet
        for stock in project.project_stocks.all():
            if stock.label == project.title:  # assuming project.name gives the name of the project
                project_choice.append((stock.pk, str(stock.label)))
        form.fields["origin_of_transfer"].choices = project_choice
        
        for stock in project.project_stocks.all():
            if stock.label != project.title : 
                project_choices.append((stock.pk, str(stock.label)))
        # Affecte également les choix de projet à la liste déroulante "destination_of_transfer" du formulaire
        form.fields["destination_of_transfer"].choices = project_choices

        context['form'] = form  # Ajoute le formulaire avec les choix pré-remplis au contexte pour le rendre dans le template
        context['method'] = "post"  # Indique que le formulaire doit être soumis via une requête POST

        return context  # Renvoie le contexte modifié contenant le formulaire et la méthode à utiliser pour rendre le template associé à cette vue


@method_decorator(login_required, name='dispatch')
class TransferUpdateViewout(FormMessagesMixin, UpdateView):
    """
      vue de mise à jour d'un transfer
    """
    model = Transfer
    form_class = TransferFormout
    template_name = "pages/transfer/create_out.html"
    success_url = reverse_lazy('Transfer_lists_out')


   
    def get_form_invalid_message(self):
        return u" impossible d' effectueé la Modification!"

    def get_form_valid_message(self):
        return u" Modification effectueé avec succès!"

   # Recupère l'identifiant de l'objet caché dans le formulaire pour modifier le bon objet
    def get_object(self, **kwargs):
        print("Transfer Update data : {}".format(self.request.body))
        return Transfer.objects.get(pk=self.request.POST.get('pk'))

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        context['method'] = "put"
        return context



@method_decorator(login_required, name='dispatch')
class TransferDeleteViewout(DeleteView):
    model = Transfer
    template_name="pages/transfer/delete.html"
    success_url = reverse_lazy('ma_vue')


@method_decorator(login_required, name='dispatch')
class TransferDetailViewout(DetailView):
    """
        Vue d'affichage d'un stock
    """
    model = Transfer
    template_name = "pages/transfer/create_out.html"

    
    def get_context_data(self, **kwargs):
        """
            Surchage l'objet context
        """
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        obj = self.get_object()
        print(f"Detail request : {obj.pk}")
        context['form'] = TransferFormout(instance=obj)
        context['object'] = obj
        context['method'] = "put"
        return context
   
    
    

    