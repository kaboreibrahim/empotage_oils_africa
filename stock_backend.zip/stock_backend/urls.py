from django.urls import path

from .views import reset_password, index, ArticleListView, ArticleCreateView, \
    ArticleDetailView, ArticleUpdateView, AttributeListView, AttributeCreateView, ArticleVariantListView, \
    ArticleVariantCreateView, AttributeDetailView, AttributeUpdateView, CategoryCreateView, CategoryDetailView, \
    CategoryUpdateView, CategoryListView, ProjectCreateView, ProjectListView, ProjectUpdateView, ProjectDetailView,\
    TransferListView,TransferCreateView,TransferUpdateView, AttributeValueListView,AttributeValueUpdateView,TransferDetailView,\
     AttributeValueCreateView, ArticleSerialLotDetailView,ArticleVariantDetailView,AttributeValueDetailView,ArticleVariantUpdateView,\
     ArticleSerialLotCreateView,ArticleSerialLotListView,ArticleSerialLotUpdateView ,StockUpdateView,StockListView,StockCreateView,\
     StockDetailView,view_stock,expired_serial_lots_view,indicateur,TransferListViewout,TransferCreateViewout,TransferUpdateViewout,\
          TransferDetailViewout,no_data_page,FlexitankListView,HeatingPadListView,RapportListView,RapportCreateView,generate_pdf,HeatingPadCreateView,FlextanksCreateView,FirstprojectListView,FirstprojetCreateView
     
urlpatterns = [
     
     
     #Articlevariant views
     
    path('articlevariant/list',ArticleVariantListView.as_view(),name="ArticleVariant_list"),
    path('articlevariant/new', ArticleVariantCreateView.as_view(), name="ArticleVariant_new"),
    path('articlevariant/update/',ArticleVariantUpdateView.as_view(),name='ArticleVariant_update'),
    path('articlevariant/edit/<uuid:pk>/',
         ArticleVariantDetailView.as_view(), name='ArticleVariant_edit'),
    
    #serie number lot views
    path('number-series-lot/',ArticleSerialLotListView.as_view(), name="ArticleSerialLot_list"),
    path('number-series-lot/create', ArticleSerialLotCreateView.as_view(),name="ArticleSerialLot_create"),
    path('number-series-lot/update/',ArticleSerialLotUpdateView.as_view(),name='ArticleSerialLot_update'),
    path('number-series-lot/edit/<uuid:pk>/',
         ArticleSerialLotDetailView.as_view(), name='ArticleSerialLot_edit'),
    # Common views
    path('password-reset/', reset_password, name='password-reset'),
    path('dashboard/', index, name='index'),
   

    # Attributes views
    path('attribute/list', AttributeListView.as_view(), name='attribute-list'),
    path('attribute/new', AttributeCreateView.as_view(), name='attribute-new'),
    path('attribute/update',
         AttributeUpdateView.as_view(), name='attribute-update'),
    path('attribute/edit/<uuid:pk>',
         AttributeDetailView.as_view(), name='attribute-edit'),
    
     # valeur attribut views
     path('attribute/value/list',AttributeValueListView.as_view(), name='attributevalue_list'),
     path('attribute/value/new',AttributeValueCreateView.as_view(), name='attributevalue_new'),
     path('attribute/value/update',AttributeValueUpdateView.as_view(), name='attributevalue_update'),
     path('attribute/value/edit/<uuid:pk>',
          AttributeValueDetailView.as_view(), name='attributevalue_edit'),
     
    # Categories views
    path('category/list', CategoryListView.as_view(), name='category-list'),
    path('category/new', CategoryCreateView.as_view(), name='category-new'),
    path('category/update',
         CategoryUpdateView.as_view(), name='category-update'),
    path('category/edit/<uuid:pk>',
         CategoryDetailView.as_view(), name='category-edit'),

    # Projects views
    path('project/list', ProjectListView.as_view(), name='project-list'),
    path('project/new', ProjectCreateView.as_view(), name='project-new'),
    path('project/update',
         ProjectUpdateView.as_view(), name='project-update'),
    path('project/edit/<uuid:pk>',
         ProjectDetailView.as_view(), name='project-edit'),

    # Articles views
    path('article/list',ArticleListView.as_view(), name='article_list'),
    path('article/<uuid:article>/variants/list',
         ArticleVariantListView.as_view(), name='article-variants-list'),
    path('article/<uuid:article>/variants/create',
         ArticleVariantCreateView.as_view(), name='article-variant-create'),
    path('article/new', ArticleCreateView.as_view(), name='article-new'),
    path('article/update',
         ArticleUpdateView.as_view(), name='article-update'),
    path('article/edit/<uuid:pk>',
         ArticleDetailView.as_view(), name='article-edit'),
    
     #transfert views
     
     path('transfer/list/',TransferListView.as_view(),name='Transfer_lists'),
     path('transfer/list_out/',TransferListViewout.as_view(),name='Transfer_lists_out'),
     path('transfer/new/',TransferCreateView.as_view(),name='Transfer_new'),
     path('transfer/new_out/',TransferCreateViewout.as_view(),name='Transfer_new_out'),
     path('transfer/update/',TransferUpdateView.as_view(),name='Transfer_update'),
     path('transfer/update_out/',TransferUpdateViewout.as_view(),name='Transfer_update_out'),
     path('transfer/edit/<uuid:pk>/',
          TransferDetailView.as_view(), name='Transfer_edit'),
     path('transfer/edit/out/<uuid:pk>/',
          TransferDetailViewout.as_view(), name='Transfer_edit_out'),

     path('transfer/ma_vue/stock/', view_stock, name='view_stock'),
     
     path('no_data/', no_data_page, name='no_data_page'), 



     #path('transfer/<int:pk>/delete/',TransferDeleteView.as_view(), name='Transfer_delete'),


     #stockviews
     path('stock/list/',StockListView.as_view(),name='stock_list'),
     path('stock/create/',StockCreateView.as_view(),name='stock_new'),
     path('stock/update/',StockUpdateView.as_view(),name='stock_update'),
     path('stock/edit/<uuid:pk>/',
         StockDetailView.as_view(), name='stock_edit'),
     path('expired_serial_lots/', expired_serial_lots_view, name='expired_serial_lots'),
     
     path('indicateur/',indicateur,name='indicateur_cite'),
     
     
     #view des flexitanks
     
     path('flexitanks/list/',FlexitankListView.as_view(), name='Flexitank_list'),
     path('flexitanks/create/',FlextanksCreateView.as_view(), name='Flexitanks_create'),
     
     #view des heating 
     path('heating/list/', HeatingPadListView.as_view(), name='HeatingPad_list'),  # Correction du nom
     path('heating/create/', HeatingPadCreateView.as_view(), name='HeatingPad_create'),  # Correction du nom
     
     
     #view des rapport 
     
     path('rapport/list',RapportListView.as_view(),name='Rapport_list'),
     path('rapport/create',RapportCreateView.as_view(),name='Rapport_new'),
     path('rapport/<uuid:rapport_id>/pdf/', generate_pdf, name='generate_pdf'),
     
     
     #view des Projects
     
     path('projects/list',FirstprojectListView.as_view(),name='firstprojet_list'),
     path('projects/create',FirstprojetCreateView.as_view(),name='firstprojet_create')
]


