from django.dispatch import receiver
from django.http import HttpRequest, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse, reverse_lazy
from stock_backend.forms import ArticleSerialLotForm
from stock_backend.models import ArticleSerialLot
from django.views.generic.edit import CreateView, DeleteView, UpdateView
from django.views.generic import ListView, DetailView
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from braces.views import FormMessagesMixin
from django.contrib import messages
from datetime import datetime, timezone
from django.core.mail import send_mail
from django.contrib.auth.decorators import user_passes_test



def expired_serial_lots_view(request):
    # Retrieve rows where the expiration date has arrived
    current_datetime = datetime.now().replace(tzinfo=timezone.utc)
    expired_serial_lots = ArticleSerialLot.objects.filter(expiry_date__lte=current_datetime)

    # Send email notifications for each expired serial lot
    for serial_lot in expired_serial_lots:
        warning_message = f"l'article {serial_lot.article_variant} a expire"
       
    return render(request, 'pages/numero_serie/produit_avarier.html', {'expired_serial_lots': expired_serial_lots})
@method_decorator(login_required, name='dispatch')
class ArticleSerialLotListView(ListView):
    """
        vue d'affichage de la liste des numeros de serie
    """
    model =  ArticleSerialLot
    context_object_name = 'ArticleSerialLot_list'
    template_name = "pages/numero_serie/list.html"


    def get_queryset(self):
        date_actuelle = datetime.now().replace(tzinfo=timezone.utc)

        queryset = ArticleSerialLot.objects.all()
        return queryset 
  
@method_decorator(login_required, name='dispatch')
class  ArticleSerialLotCreateView(FormMessagesMixin, CreateView):
    """
      Vue de création d'un transfer
    """
    model = ArticleSerialLot
    form_class = ArticleSerialLotForm
    template_name="pages/numero_serie/create.html"
    success_url=reverse_lazy('ArticleSerialLot_list')
    form_invalid_message="Oups,quelque chose s'est ma passé!"
  
    
    def get_form_valid_message(self):
        return u"{0} crée avec succés!".format(self.object.name)
    
    def post(self, request: HttpRequest, *args, **kwargs):
        # Look up the author we're interested in.
        print(f"Transfer Post : {request.POST}")
        # Actually record interest somehow here!
        form = ArticleSerialLotForm(request.POST)
        if form.is_valid():
            form.save()
            date_expire=form.cleaned_data['expiry_date']
            print(date_expire)
            
            messages.add_message(request,messages.SUCCESS,"Enregistrement effectuer avec succés  " )
            return HttpResponseRedirect(reverse('ArticleSerialLot_list'), {"form": form})
        else:
            print(f"Transfer form errors : {form.errors}")
            messages.add_message(request,messages.ERROR," ERREUR !!! LE CODE ENTRE EXISTE DEJA " )
            return HttpResponseRedirect(reverse('ArticleSerialLot_create'), {"form": form})
    
    
    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        context['form'] = ArticleSerialLotForm
        context['method'] = "post"
        return context
    
    

@method_decorator(login_required, name='dispatch')
class ArticleSerialLotUpdateView(FormMessagesMixin, UpdateView):
    """
      vue de mise à jour d'un transfer
    """
    model = ArticleSerialLot
    form_class = ArticleSerialLotForm
    template_name = "pages/numero_serie/create.html"
    success_url = reverse_lazy('ArticleSerialLot_list')
    form_invalid_message = "Oups, quelque chose s'est mal passé!"

   
    def get_form_valid_message(self):
        return u" Modification effectueé avec succès!"
    # Recupère l'identifiant de l'objet caché dans le formulaire pour modifier le bon objet
    def get_object(self, **kwargs):
        print("ArticleSerialLot Update data : {}".format(self.request.body))
        return ArticleSerialLot.objects.get(pk=self.request.POST.get('pk'))

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        context['method'] = "put"
        return context

@method_decorator(login_required, name='dispatch')
class ArticleSerialLotDeleteView(DeleteView):
    model = ArticleSerialLot
    success_url = reverse_lazy('Transfer_lists')
   
@method_decorator(login_required, name='dispatch')
class  ArticleSerialLotDetailView (DetailView):
    """
        Vue d'affichage d'un stock
    """
    model = ArticleSerialLot
    template_name = "pages/numero_serie/create.html"

    def get_context_data(self, **kwargs):
        """
            Surchage l'objet context
        """
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        obj = self.get_object()
        print(f"Detail request : {obj.pk}")
        context['form'] = ArticleSerialLotForm(instance=obj)
        context['object'] = obj
        context['method'] = "put"
        return context
  