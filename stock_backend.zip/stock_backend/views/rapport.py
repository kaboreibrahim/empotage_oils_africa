from django.http import HttpRequest, HttpResponseRedirect
from django.urls import reverse, reverse_lazy
from stock_backend.forms import ProjectForm,RapportForm
from stock_backend.models import *
from django.views.generic.edit import CreateView, DeleteView, UpdateView
from django.views.generic import ListView, DetailView
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from braces.views import FormMessagesMixin
from django.shortcuts import render
from django.contrib import messages
from django.http import HttpResponse
from django.utils import timezone
import os
from django.conf import settings

@method_decorator(login_required, name='dispatch')
class RapportListView(ListView):
    """
        vue d'affichage de la liste des projects
    """
    model = Rapport
    context_object_name = 'Rapport_list'
    template_name = "pages/Rapport/list.html"

    def get_queryset(self):
        queryset = Rapport.objects.all()
        return queryset



@method_decorator(login_required, name='dispatch')
class RapportCreateView(FormMessagesMixin, CreateView):
    """
      Vue de création d'un project
    """
    model = Rapport
    form_class = RapportForm
    template_name = "pages/Rapport/create.html"
    success_url = reverse_lazy('Rapport_list')
    form_invalid_message = "Oups, quelque chose s'est mal passé!"

    def get_form_valid_message(self):
        return u"{0} crée avec succés!".format(self.object.title)

    def post(self, request: HttpRequest, *args, **kwargs):
        form = RapportForm(request.POST)
        if form.is_valid():
            rapport = form.save()  # Enregistrer le rapport d'abord
           
            # Mettre à jour l'état des flexitanks
            for flexitank in rapport.flexitanks.all():
                flexitank.etat = 'SORTIE'
                flexitank.date_sortie = timezone.now()  # Attribuer la date actuelle
                flexitank.save()


            # Mettre à jour l'état des heating pads
            for heating_pad in rapport.heating_pads.all():
                heating_pad.Etat = 'SORTIE'
                heating_pad.date_sortie = timezone.now()  # Attribuer la date actuelle
                heating_pad.save()
                
             # Changer le statut du projet associé
            projet = rapport.Project  # Récupérer le projet associé
            projet.statut = 'terminé'  # Changer le statut à 'terminé'
            projet.save()  # Enregistrer les modifications
            
            messages.add_message(request, messages.SUCCESS, "Enregistrement effectué avec succès!")
            return HttpResponseRedirect(reverse('Rapport_list'))
        else:
            print(f"Rapport form errors : {form.errors}")
            return HttpResponseRedirect(reverse('Rapport_new'), {"form": form})
    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in the publisher
        context['form'] = RapportForm
        context['method'] = "post"
        return context
    
    
    
import os
from django.conf import settings
from django.http import HttpResponse
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle, Spacer, Image
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from datetime import datetime

def format_date(dt):
    if dt:
        return dt.strftime("%d/%m/%Y à %Hh%M")
    return ""
def generate_pdf(request, rapport_id):
    # Récupérer le rapport à partir de l'ID
    rapport = Rapport.objects.get(id=rapport_id)
    flexitanks = rapport.flexitanks.all()
    heating_pads = rapport.heating_pads.all()

    # Créer une réponse HTTP
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="rapport de sortir {rapport.Project}.pdf"'

    # Créer le PDF
    pdf = SimpleDocTemplate(response, pagesize=letter)
    elements = []

    # Ajouter le titre principal
    styles = getSampleStyleSheet()
    elements.append(Paragraph(f'Rapport de sortie de Flexitank & Heating Pad du dossier {rapport.Project}', styles['Title']))
    elements.append(Spacer(1, 0.2 * inch))  # Espacement

    # Ajouter l'image
    image_path = os.path.join(settings.BASE_DIR, 'static', 'img', 'logo.jpg')
    image = Image(image_path)
    image.drawHeight = 1.5 * inch  # Ajustez la hauteur de l'image
    image.drawWidth = 2.0 * inch  # Ajustez la largeur de l'image

    # Créer une table pour l'image à droite et les informations de l'en-tête à gauche
    header_data = [
        [Paragraph(f'Projet: {rapport.Project}', styles['Normal']),
         Paragraph(f'TRD: {rapport.Project.TRD}', styles['Normal']),
         Paragraph(f'Client: {rapport.client}', styles['Normal']),
         Paragraph(f'Date de création: {format_date(rapport.Date_creation_rapport)}', styles['Normal']),
         image]
    ]
    
    header_table = Table(header_data, colWidths=[None, None, None, None, 2.0 * inch])
    header_table.setStyle(TableStyle([
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),  # Align vertical to the middle
        ('ALIGN', (4, 0), (4, 0), 'RIGHT'),  # Align image to the right
    ]))
    
    elements.append(header_table)
    elements.append(Spacer(1, 0.5 * inch))  # Espacement après le tableau d'en-tête

    # Créer le tableau pour les Flexitanks
    if flexitanks:
        elements.append(Paragraph('Liste des Flexitanks', styles['Title']))  # Titre du tableau Flexitanks
        flexitank_data = [['N°', 'Code', 'Date d\'entrée', 'Date de sortie', 'Fournisseur']]
        for i, flexitank in enumerate(flexitanks, start=1):
            flexitank_data.append([
                i,
                flexitank.code,
                format_date(flexitank.date_entre),
                format_date(flexitank.date_sortie),
                flexitank.DIST
            ])

        flexitank_table = Table(flexitank_data)
        flexitank_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ]))
        elements.append(flexitank_table)
        elements.append(Paragraph('<br/>', styles['Normal']))  # Espacement

    # Créer le tableau pour les Heating Pads
    if heating_pads:
        elements.append(Paragraph('Liste des Heating Pads', styles['Title']))  # Titre du tableau Heating Pads
        heating_pad_data = [['N°', 'Code', 'Date d\'entrée', 'Date de sortie', 'Fournisseur']]
        for i, heating_pad in enumerate(heating_pads, start=1):
            heating_pad_data.append([
                i,
                heating_pad.code,
                format_date(heating_pad.date_entre),
                format_date(heating_pad.date_sortie),
                heating_pad.DIST
            ])

        heating_pad_table = Table(heating_pad_data)
        heating_pad_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ]))
        elements.append(heating_pad_table)

    # Générer le PDF
    pdf.build(elements)
    return response

 